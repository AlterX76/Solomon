

#include "GameServerClass.h"
#include "PluginLoader.h" // effetua il caricamento del plugin
#include "tictactoebridgeprovider.h"
//
// indica il numero del messaggio, all'interno del servizio, che indica la shortcut recuperata durante il caricamento dei moduli
#define MESSAGE_SHORTCUT_NUMBER     3


int  main(int argc, char *argv[])
{
    // verifica dei parametri necessari:
    if (argc != 2) {
        printf("\n\nusage: %s pluginPathAndFile\n\n", argv[0]);
        return (EXIT_FAILURE);
    }
    //
    // il percorso con il nome del plugin da caricare sara' passato tramite parametro
    PluginLoader				loader(argv[1]);
    ISpecializedPlugin          *plug = loader.GetPlugin();
    TicTacToeBridgeProvider     bridge;
    GameServerClass				*server = NULL;
    //
    // verifica che il plugin sia stato caricato con successo:
    if (plug != NULL) {
        setvbuf(stdout, NULL, _IONBF, 0);
        bridge.setPlugin(plug);
        server = new GameServerClass(&bridge);
        server->StartServerListener();
        printf("\nError starting server: %d", errno);
    }
    else
        printf("\nErrore: impossibile caricare il plugin specificato [%s]\n", argv[1]);
    return (EXIT_SUCCESS);
}

