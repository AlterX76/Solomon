#ifndef TCP_TcpEmbeddedServer_H
#define TCP_TcpEmbeddedServer_H

#include <QObject>
#include <QMutex>
#include <QTimer>
#include "TicTacToeHeader.h"
#include "GameClientClass.h"
#include "IGameClientBridgeProvider.h"
//
//
// change settings to communicate towards your developer server:
#define REMOTE_SERVER_NAME  "put.your.server.com" 
#define REMOTE_SERVER_PORT  24555



class TcpEmbeddedServer : public QObject, private GameClientClass, private IGameClientBridgeProvider  {
    Q_OBJECT

    public:
        TcpEmbeddedServer(QString *localIp, u_short localPort, QString *remoteIp, u_short remotePort);
        ~TcpEmbeddedServer();

        void                        emitNoStartedTcpEmbeddedServer();
        integer                     getClientTicket(); // if we want to communicate to using UDP/IP
        boolean                     AsyncSendRequestOverTcp(TicTacToeHeader *header, AbstractBodyMessage *body);
        boolean                     AsyncSendRequestOverUdp(TicTacToeHeader *header, AbstractBodyMessage *body);
        AbstractResponseMessage *   SyncSendRequestOverTcp(ClientEnvironment *clientEnv, AbstractBodyMessage *body, TicTacToeHeader *header, u_short timeout);

        using GameClientClass::AsyncSendFileStream;        
        using GameClientClass::isServerStarted;
        using GameClientClass::isConnected;

    signals:
        void                        startedGameNotification(QString nickname, quint8 action);
        void                        closedGameNotification();
        void                        newGameActionNotification(quint16 actionIndex);
        void                        TcpEmbeddedServerStarted(bool result);

    private slots:
        void                        emitStartedTcpEmbeddedServer();

    public slots:
        void                        Stop();
        void                        Start();

    private:
        // IGameClientBridgeProvider interface
        virtual void                clientConnectedToServer();
        virtual void                clientDisconnectedFromServer();
        virtual boolean             clientDidHandleServerRequest(const AbstractHeaderMessage *header, DataContainerReader *binaryBody);
        AbstractHeaderMessage *     clientCreateHeaderMessage();
        void                        clientWillStartTransfer(const AbstractHeaderMessage *header, u_integer id, const buffer_pointer fileName);
        void                        clientDidFinishTranfer(const AbstractHeaderMessage *header, u_integer id, const buffer_pointer fileName, TFileUploadResult sent);
};

#endif // TcpEmbeddedServer_H
