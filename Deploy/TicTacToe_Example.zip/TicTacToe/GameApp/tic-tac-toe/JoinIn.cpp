

#include "communicator.h"
#include "BodyMessage_80_1.h"
#include "ClientEnvironment.h"



void Communicator::proceedWithJoin(QString myNick)
{
    BodyMessage_80_1		body;
    ClientEnvironment		objEnv;
    AbstractResponseMessage *response = NULL;
    QString                 msg;
    ResponseMessage_80_1    *infoLogin = NULL;

    if (this->localUser.inGameStatus || this->localUser.inWaitStatus)
        this->joinOut();
    emit joinInProgress();
    qApp->processEvents();    
    try {
        if (this->areInterfaceAvailable()) {
            this->mutexCheckInterface.lock();
            objEnv.SetServerIPAddr((caracter *) this->serverIP->toUtf8().constData());
            objEnv.SetClientIPAddr((caracter *) this->localIP->toUtf8().constData());
            this->mutexCheckInterface.unlock();
            objEnv.SetServerUDPPort(REMOTE_SERVER_PORT);
            body.SetNickname(myNick.toUtf8().constData());
            response = (AbstractResponseMessage*)this->asyncTcpServer->SyncSendRequestOverTcp(&objEnv, &body, &header, 6); // timeout dipends on version of server you are working on
        }
        if (response != NULL) {            
            infoLogin = (ResponseMessage_80_1 *)response;
            header.SetSessionToken((char*)infoLogin->GetSessionToken()); // IMPORTANT: we use same header for all communication
            localUser.session_login = (char*)infoLogin->GetSessionToken();
            if (infoLogin->GetResultCode() == retNoErrorWait) {
                this->localUser.inWaitStatus = true;
                this->localUser.inGameStatus = false;
                this->localUser.firstActionInGame = infoLogin->GetFirstActionInGame();
                emit gameJoinedInWait();
            }
            else if (infoLogin->GetResultCode() == retNoErrorGame) {
                this->localUser.inGameStatus = this->networkUser.inGameStatus = true;
                this->localUser.firstActionInGame = infoLogin->GetFirstActionInGame();
                this->networkUser.nickname = (caracter*)infoLogin->GetNickname();
                emit gameJoinedInChat(this->networkUser.nickname, infoLogin->GetFirstActionInGame());
            }
            else {
                this->networkUser.inGameStatus = this->networkUser.inWaitStatus = false;
                this->localUser.inGameStatus = this->localUser.inWaitStatus = false;
                emit gameJoinInErrorDuplicate("Error: check nickname (min 5 chars)");
            }
        }
    }
    catch (...) {
        ; // avoid problems :)
    }
    if (response == NULL)
        msg = tr("Ooppsss: you are facing a server related problem: maybe server is in maintenance mode!");
    else
        MemoryUtil::DeleteMemory(&response, TRUE);
    emit this->error(msg);
}
