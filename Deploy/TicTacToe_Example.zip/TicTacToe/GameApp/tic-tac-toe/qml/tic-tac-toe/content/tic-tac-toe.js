
function winner(board, player)
{
    for (var i=0; i<3; ++i) {
        if (board.children[i].state !== "" && board.children[i].state === board.children[i+3].state && board.children[i].state === board.children[i+6].state)
            if (board.children[i].state === player) return true

        if (board.children[i*3].state !== "" && board.children[i*3].state === board.children[i*3+1].state && board.children[i*3].state === board.children[i*3+2].state)
            if (board.children[i*3].state === player) return true
    }

    if (board.children[0].state !== "" && board.children[0].state === board.children[4].state && board.children[0].state === board.children[8].state)
        if (board.children[0].state === player) return true

    if (board.children[2].state !== "" && board.children[2].state === board.children[4].state && board.children[2].state === board.children[6].state)
        if (board.children[2].state === player) return true

    return false
}

function restartGame()
{
    game.running = true
    game.cleanBoard()
    game.restart()
}


function isGameToBeRestarted() {
    var posAvailable = false;

    for (var i = 0; i < 9; i++) {
        if (canPlayAtPos(i) === true) {
            posAvailable = true;
            break;
        }
    }
    return (posAvailable == false);
}


function makeMove(pos, player)
{
    board.children[pos].state = player
    if (winner(board, bridge.getInfoAboutMe())) {
        gameFinished("YOU WON THIS MATCH!")
        incrementMyScore();
        return true
    }
    else {
        return false
    }
}

function canPlayAtPos(pos)
{
    return board.children[pos].state === ""
}


function gameFinished(message)
{
    waitLabel.visible = false;
    messageDisplay.text = message
    messageDisplay.visible = true
    game.running = false
}

