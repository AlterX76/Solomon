

function startGameNotification(nickname, action) {
    game.running = true
    game.networkNickname = nickname;
    mySymbolImage.setSymbol()
    if (bridge.getInfoAboutMe() === "O") {
        canvas.enabled = false;
        waitLabel.text = qsTr("Waiting for action from " + nickname + qsTr("..."))
        waitLabel.visible = true;
    }
    else {
        waitLabel.visible = true;
        canvas.enabled = true;
        waitLabel.text = qsTr("It is your turn, " + textNickname.text.trim() + "!")
    }
    buttonExit.enabled = true;
    infoNetworkPlayer.text = qsTr("Playing tic tac toe with: ") + nickname;
    infoNetworkPlayer.visible = true;
    canvas.visible = true;
}


function closedGameNotification() {
    waitLabel.text = qsTr("Peer has closed connection :(")
    waitLabel.visible = true;
    canvas.visible = false
    buttonExit.enabled = false
    buttonStartGame.enabled = true
    textNickname.enabled = true
    infoNetworkPlayer.text = ""
    game.running = false;
    game.cleanBoard();
}

function joinInNetworkProgressNotification() {
    waitLabel.text = qsTr("Connection to the system...")
    waitLabel.visible = true;
}

function joinedInNetworkNotificaton() {
    waitLabel.text = qsTr("Waiting for a player...")
    waitLabel.visible = true;
    buttonExit.enabled = true;
}

function errorNotification(msg) {
    waitLabel.text = msg
    waitLabel.visible = true;
    buttonStartGame.enabled = true;
    textNickname.enabled = true;
}


function joinOutFromNetworkNotificaton() {
    console.log("trying to disconnect...")
    waitLabel.text = qsTr("Disconnection in progress...")
    waitLabel.visible = true;
}

function joinOutExecutedError() {
    waitLabel.text = qsTr("PROBLEM WITH DISCONNECTION!")
    waitLabel.visible = true;
}

function joinOutExecuted() {
    console.log("logout executed sucessfully")
    Qt.quit()
}

function newActionNotification(index) {
    game.actionFromPeer(index, getRemotePlayerInfo())
    waitLabel.visible = true
    canvas.enabled = true
    waitLabel.text = qsTr("It is your turn, " + textNickname.text.trim() + "!")
    game.checkAndRestartGameIfTerminated(getRemotePlayerInfo())
}

function getRemotePlayerInfo() {
    var player;

    if (bridge.getInfoAboutMe() === "X") // opposite
        player = "O";
    else
        player = "X";
    return player;
}
