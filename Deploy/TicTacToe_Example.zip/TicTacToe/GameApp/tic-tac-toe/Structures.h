

#ifndef SHAKESTRUCTURES_H
    #define SHAKESTRUCTURES_H

    #include <QString>    
    #include <string>

    using std::string;
    //
    //
    // user information:
    typedef struct  TUser {
        string          session_login;
        QString         nickname;
        quint8          firstActionInGame;
        quint32         ticket;
        bool            inGameStatus;
        bool            inWaitStatus;

        TUser(): session_login(""), nickname(QString::null), firstActionInGame(0), ticket(0), inGameStatus(false), inWaitStatus(false) {}
    } TUser;

#endif
