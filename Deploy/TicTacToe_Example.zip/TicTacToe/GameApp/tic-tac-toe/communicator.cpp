
#include "communicator.h"
#include <QTimer>
#include <QPixmap>
#include <QDebug>
#include <QNetworkInterface>



Communicator::Communicator(QObject *parent) : QObject(parent), localIP(NULL), serverIP(NULL), asyncTcpServer(NULL)
{
    QNetworkConfigurationManager    netConfigManager;
    QLocale                         localeLang = QLocale::system();

    qsrand(time(NULL));
    this->netSession = new QNetworkSession(netConfigManager.defaultConfiguration(), this);    
    if (this->netSession->isOpen()) {
        this->inizialize();
    }
    else {
        connect(this->netSession, SIGNAL(opened()), this, SLOT(inizialize()));
        this->netSession->open();
    }
    this->managerNetwork = new QNetworkAccessManager(this);    
}


Communicator::~Communicator()
{
    MemoryUtil::DeleteMemory(&this->serverIP, TRUE);
    MemoryUtil::DeleteMemory(&this->localIP, TRUE);
    MemoryUtil::DeleteMemory(&this->asyncTcpServer, TRUE);
}


void Communicator::inizialize()
{
    disconnect(this->netSession, SIGNAL(opened()), this, SLOT(inizialize()));
    disconnect(this->netSession, SIGNAL(stateChanged(QNetworkSession::State)), this, SLOT(networkStateChanged(QNetworkSession::State)));
    connect(this->netSession, SIGNAL(stateChanged(QNetworkSession::State)), this, SLOT(networkStateChanged(QNetworkSession::State)));
    this->resolveAndSetServer(QString(REMOTE_SERVER_NAME));
    this->setLocalIP();
    this->createEmbeddedServer();
}


void Communicator::processEvents()
{
    QCoreApplication::processEvents();
}

QString Communicator::getInfoAboutMe()
{
    return (this->localUser.firstActionInGame == 0 ? "O" : "X");
}


bool Communicator::resolveAndSetServer(QString remoteServer)
{
    bool                ret = false;
    QList<QHostAddress> resolved = QHostInfo::fromName(remoteServer.trimmed()).addresses();

    if (resolved.length() > 0) {
        MemoryUtil::DeleteMemory(&this->serverIP, TRUE);
        this->serverIP = new QString(resolved[0].toString());
        qDebug("Resolution of %s: %s", REMOTE_SERVER_NAME, this->serverIP->toUtf8().constData());
        ret = true;
    }
    return (ret);
}

//
// esegue ricerca per le interfacce di rete da utilizzare e setta i membri interni
void Communicator::setLocalIP()
{
    this->mutexCheckInterface.lock();
#if defined WIN32 | defined MACOSX | defined LINUX
    MemoryUtil::DeleteMemory(&this->serverIP, TRUE);
    foreach(QNetworkInterface interf, QNetworkInterface::allInterfaces()) {
        if (interf.flags().testFlag(QNetworkInterface::IsUp) && !interf.flags().testFlag(QNetworkInterface::IsLoopBack))
            foreach (QNetworkAddressEntry entry, interf.addressEntries())
               if ( interf.hardwareAddress() != "00:00:00:00:00:00" && entry.ip().toString().contains(".") && !interf.humanReadableName().contains("VM")) {
                   this->localIP = new QString(entry.ip().toString());
                   qDebug("Client IP: %s", this->localIP->toUtf8().constData());
                   break;
               }
        if (this->localIP != NULL)
            break;
     }
#elif defined ANDROID
    foreach(QNetworkInterface interface, QNetworkInterface::allInterfaces()) {
        if (interface.flags().testFlag(QNetworkInterface::IsRunning))
            foreach (QNetworkAddressEntry entry, interface.addressEntries()) {
                if (entry.ip().toString().contains("127.0.0.1") == false && entry.ip().toString().contains(":") == false) {
                    MemoryUtil::DeleteMemory(&this->localIP, TRUE);
                    this->localIP = new QString(entry.ip().toString());
                    qDebug("Client IP: %s", this->localIP->toUtf8().constData());
                    break;
                }
            }
        }
#elif BLACKBERRY
    foreach(QNetworkInterface interface, QNetworkInterface::allInterfaces()) {
        if (interface.flags().testFlag(QNetworkInterface::IsRunning) && interface.flags().testFlag(QNetworkInterface::IsUp) && interface.flags().testFlag(QNetworkInterface::IsLoopBack) == false)
            foreach (QNetworkAddressEntry entry, interface.addressEntries()) {
                if (entry.ip().toString().contains(":") == false && interface.humanReadableName().contains("usb") == false && interface.hardwareAddress() != "00:00:00:00:00:00") {
                    MemoryUtil::DeleteMemory(&this->localIP, TRUE);
                    this->localIP = new QString(entry.ip().toString());
                    qDebug("Client IP: %s", this->localIP->toUtf8().constData());
                    this->mutexCheckInterface.unlock();
                    return;
                }
            }
        }
#endif
      this->mutexCheckInterface.unlock();
}

void Communicator::createEmbeddedServer()
{
    u_short port = 0;

    this->mutexCheckInterface.lock();
    if (this->serverIP == NULL) this->resolveAndSetServer(QString(REMOTE_SERVER_NAME));
    this->mutexCheckInterface.unlock();
    if (this->areInterfaceAvailable()) {        
        MemoryUtil::DeleteMemory(&this->asyncTcpServer, TRUE);
        port = ((qrand() + 1024) % USHRT_MAX) + 1024;
        qDebug("Server listening on port %d", port);
        this->mutexCheckInterface.lock();
        this->asyncTcpServer = new TcpEmbeddedServer(this->localIP, port, this->serverIP, REMOTE_SERVER_PORT);

        connect(this->asyncTcpServer, SIGNAL(closedGameNotification()), this, SLOT(internalClosedGameNotification()));
        connect(this->asyncTcpServer, SIGNAL(startedGameNotification(QString, quint8)), this, SLOT(internalStartedGameNotification(QString,quint8)));
        connect(this->asyncTcpServer, SIGNAL(newGameActionNotification(quint16)), this, SIGNAL(newGameActionNotification(quint16)));
        QObject::connect(this->asyncTcpServer, SIGNAL(TcpEmbeddedServerStarted(bool)), this, SLOT(TcpEmbeddedServerStarted(bool)));
        this->asyncTcpServer->Start();
        this->mutexCheckInterface.unlock();
    }
}



void Communicator::TcpEmbeddedServerStarted(bool started)
{
    if (started) {
        QObject::disconnect(this->asyncTcpServer, SIGNAL(TcpEmbeddedServerStarted(bool)), this, SLOT(TcpEmbeddedServerStarted(bool)));
        this->localUser.ticket = this->asyncTcpServer->getClientTicket();
    }
}


void Communicator::internalStartedGameNotification(QString nickname, quint8 first_action)
{
    this->networkUser.nickname = nickname;
    this->localUser.inWaitStatus = this->networkUser.inWaitStatus = false;
    this->localUser.inGameStatus = this->networkUser.inGameStatus = true;
    emit startedGameNotification(nickname, first_action);
}

void Communicator::internalClosedGameNotification()
{
    this->localUser.inWaitStatus = this->networkUser.inWaitStatus = false;
    this->localUser.inGameStatus = this->networkUser.inGameStatus = false;
    emit closedGameNotification();
}


void Communicator::networkStateChanged(QNetworkSession::State state)
{
    if (state == QNetworkSession::Connected) {
        qDebug("New connection established");
        try {
            if (this->netSession->isOpen()) {
                this->inizialize();
            }
            else {
                connect(this->netSession, SIGNAL(opened()), this, SLOT(inizialize()));
                this->netSession->open();
            }
        }
        catch (...) {
            qDebug()<< "Error in network state change";
        }
    }
    else if (state == QNetworkSession::Disconnected) {
        qDebug("Network connection down");
        try {                        
            this->mutexCheckInterface.lock();
            if (this->localIP != NULL) MemoryUtil::DeleteMemory(&this->localIP, TRUE);
            this->mutexCheckInterface.unlock();
            if (this->asyncTcpServer != NULL) {
                this->asyncTcpServer->Stop();
            }
        }
        catch (...) {
            qDebug("ERROR NETWORK");
        }
    }
}


bool Communicator::areInterfaceAvailable()
{
    bool ret = false;

    this->mutexCheckInterface.lock();
    if (this->localIP != NULL && this->serverIP != NULL) ret = true;
    this->mutexCheckInterface.unlock();
    return (ret);
}



void Communicator::activateTcpServerNotification()
{

}


void Communicator::quit()
{
    if (this->localUser.inGameStatus || this->localUser.inWaitStatus)
        this->joinOut();
    if (this->asyncTcpServer != NULL)
        this->asyncTcpServer->Stop();
    qApp->quit();
}


void Communicator::setScreenSaverInhibited(bool inhibit)
{
}

