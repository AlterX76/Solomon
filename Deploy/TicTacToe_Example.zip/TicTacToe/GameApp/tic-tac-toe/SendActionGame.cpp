

#include "communicator.h"
#include "BodyMessage_80_3.h"
#include <QDebug>


void Communicator::sendActionGame(quint16 action)
{
    BodyMessage_80_3    body;

    emit sendActionGameInProgress();
    qApp->processEvents();
    if (this->areInterfaceAvailable()) {
        qDebug()<<"Send action: "<< action;
        body.SetActionIndex(action);
        this->asyncTcpServer->AsyncSendRequestOverTcp(&header, &body);
    }
}
