#ifndef COMMUNICATOR_H
#define COMMUNICATOR_H

#include <QObject>
#include <QCoreApplication>
#include <QNetworkInterface>
#include <QHostInfo>
#include <QDir>
#include <QImage>
#include <QNetworkReply>
#include <QNetworkConfigurationManager>
#include <QNetworkConfiguration>
#include <QNetworkInterface>
#include <QNetworkSession>
#include "TcpEmbeddedServer.h"
#include "Solomon.h"
#include "utility.h"
#include "MemorySupport.h"
#include "AbstractHeaderMessage.h"
#include "DataContainerReader.h"
#include "ReturnStatus.h"
#include "Structures.h"
#include "TicTacToeHeader.h"


// Logic object
class Communicator : public QObject
{
    Q_OBJECT

private:
    QNetworkAccessManager           *managerNetwork;
    QMutex                          mutexCheckInterface;
    QNetworkSession                 *netSession;
    QString                         *localIP;
    QString                         *serverIP;
    QString                         nicknameCommander;
    TcpEmbeddedServer               *asyncTcpServer;
    TicTacToeHeader                 header;
    TUser                           localUser;
    TUser                           networkUser;

    void                            setLocalIP();
    bool                            resolveAndSetServer(QString remoteServer);
    void                            createEmbeddedServer();
    bool                            areInterfaceAvailable();
    void                            setScreenSaverInhibited(bool inhibit);

public:
    explicit Communicator(QObject *parent = NULL);
    ~Communicator();

signals:
    void                            error(QString error);
    //
    // --------------------------- (request 80.1) ---------------------------
    void                            joinInProgress();
    void                            gameJoinInErrorDuplicate(QString error);
    void                            gameJoinedInWait();
    void                            gameJoinedInChat(QString nickname, qint8 first_action); // 100.1

    //
    // --------------------------- (request 80.2) ---------------------------
    void                            joinOutInProgress();
    void                            joinOutExecuted();
    void                            joinOutExecutedError();
    void                            joinOutForcedByUser(); // 100.2
    //
    // --------------------------- (request 80.3) ---------------------------
    void                            sendActionGameInProgress();
    //
    // ---------------------------- NOTIFICATIONS FROM NETWORK PLAYER --------
    void                            closedGameNotification();
    void                            startedGameNotification(QString nickname, quint8 first_action);
    void                            newGameActionNotification(quint16 action);

private slots:
    void                            inizialize();
    void                            networkStateChanged(QNetworkSession::State state);
    void                            TcpEmbeddedServerStarted(bool result);
    void                            internalStartedGameNotification(QString nickname, quint8 first_action);
    void                            internalClosedGameNotification();

public slots:
    void                            processEvents();

    QString                         getInfoAboutMe();
    void                            proceedWithJoin(QString myNick); // try to start a game or wait for a new player (80.1)
    void                            joinOut(); // performs logout (either in game or in wait) (80.2)
    void                            sendActionGame(quint16 action); // send an action over network (80.3)
    void                            activateTcpServerNotification();
    void                            quit();
};

#endif // COMMUNICATOR_H
