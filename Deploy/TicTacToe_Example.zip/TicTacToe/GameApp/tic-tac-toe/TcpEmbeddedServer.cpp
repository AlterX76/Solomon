

#include "TcpEmbeddedServer.h"
#include "ReturnStatus.h"
#include "ResponseMessage_100_1.h"
#include "ResponseMessage_100_2.h"
#include "ResponseMessage_100_3.h"
#include "ResponseMessage_80_3.h"
#include <QDebug>


TcpEmbeddedServer::TcpEmbeddedServer(QString *localIp, u_short localPort, QString *remoteIp, u_short remotePort) :
    GameClientClass(this, (caracter *)localIp->toUtf8().constData(), localPort, (caracter *)remoteIp->toUtf8().constData(), remotePort, 256)
{
}

TcpEmbeddedServer::~TcpEmbeddedServer()
{
    GameClientClass::StopEmbeddedServer();
}


void TcpEmbeddedServer::Start()
{
    GameClientClass::StartEmbeddedServer();
}


void TcpEmbeddedServer::Stop()
{
    GameClientClass::StartEmbeddedServer();
}



void TcpEmbeddedServer::emitStartedTcpEmbeddedServer()
{
    emit TcpEmbeddedServerStarted(true);
}


void TcpEmbeddedServer::emitNoStartedTcpEmbeddedServer()
{
    emit this->TcpEmbeddedServerStarted(false);
}

integer TcpEmbeddedServer::getClientTicket()
{
    return (GameClientClass::getClientTicket());
}


boolean TcpEmbeddedServer::AsyncSendRequestOverTcp(TicTacToeHeader *header, AbstractBodyMessage *body)
{
    header->SetClientTicket(this->getClientTicket());
    return GameClientClass::AsyncSendRequestOverTcp(header, body);
}


AbstractResponseMessage *TcpEmbeddedServer::SyncSendRequestOverTcp(ClientEnvironment *clientEnv, AbstractBodyMessage *body, TicTacToeHeader *header, u_short timeout)
{
    header->SetClientTicket(this->getClientTicket());
    return GameClientClass::SyncSendRequestOverTcp(clientEnv, body, header, timeout);
}


void TcpEmbeddedServer::clientConnectedToServer()
{
    qDebug()<< "TcpEmbeddedServer: connected!";
    emit this->TcpEmbeddedServerStarted(true);
}

void TcpEmbeddedServer::clientDisconnectedFromServer()
{
    qDebug()<< "TcpEmbeddedServer: disconnected!";
    emit TcpEmbeddedServerStarted(false);
}

boolean TcpEmbeddedServer::clientDidHandleServerRequest(const AbstractHeaderMessage *header, DataContainerReader *binaryBody)
{
    bool    handled = true;

    if (header->GetIDService() == SERVICE_NOTIFICATION) {
        if (header->GetIDMessage() == 1) { // NOTIFICATION THAT A GAME HAS BEEN STARTED
            ResponseMessage_100_1   ret(0, 0); // you can safely ignore parameter at this stage

            ret.ParseBinary(binaryBody);
            if (ret.GetResultCode() == retNoErrorGame) // a player has joind in the game
                emit startedGameNotification(QString::fromUtf8((caracter*)ret.GetNickname()), ret.GetFirstActionInGame());
        }
        else if (header->GetIDMessage() == 2) { // A PLAYER HAS CLOSED GAME AND A NOTIFICATION HAS BEEN SENT
            ResponseMessage_100_2   ret(0, 0); // you can safely ignore parameter at this stage

            ret.ParseBinary(binaryBody);
            if (ret.GetResultCode() == retGameClosed) { // a player has closed game
                emit closedGameNotification();
            }
        }
        else if (header->GetIDMessage() == 3) {
            ResponseMessage_100_3   ret(0, 0); // you can safely ignore parameter at this stage

            ret.ParseBinary(binaryBody);
            emit newGameActionNotification(ret.GetActionIndex());
        }
    }
    else // other messages that are not notifications
        handled = false;
    return (handled);
}

AbstractHeaderMessage *TcpEmbeddedServer::clientCreateHeaderMessage()
{
    return new TicTacToeHeader();
}
