

#include "communicator.h"
#include "BodyMessage_80_2.h"
#include "ClientEnvironment.h"


void Communicator::joinOut()
{
    BodyMessage_80_2		body;
    ClientEnvironment		objEnv;
    ResponseMessage_80_2	*response = NULL;

    emit joinOutInProgress();
    qApp->processEvents();
    try {
        if (this->areInterfaceAvailable()) {
            this->mutexCheckInterface.lock();
            objEnv.SetServerIPAddr((caracter *) this->serverIP->toUtf8().constData());
            objEnv.SetClientIPAddr((caracter *) this->localIP->toUtf8().constData());
            this->mutexCheckInterface.unlock();
            objEnv.SetServerUDPPort(REMOTE_SERVER_PORT);
            response = (ResponseMessage_80_2*)this->asyncTcpServer->SyncSendRequestOverTcp(&objEnv, &body, &header, 4);
        }
        if (response != NULL) {
            if (response->GetResultCode() == retLogoutExecuted) {
                this->internalClosedGameNotification();
                emit joinOutExecuted();
            }
            else
                emit joinOutExecutedError();
        }
    }
    catch (...) {
        ; // no problems :)
    }
    if (response != NULL)
        MemoryUtil::DeleteMemory(&response, TRUE);
}
