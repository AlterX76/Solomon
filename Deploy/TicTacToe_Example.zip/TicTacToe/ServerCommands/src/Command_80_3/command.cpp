
#include "command.h"
#include "tictactoebridgeprovider.h"
#include "ISpecializedPlugin.h"



CommandRequest_XX_X::CommandRequest_XX_X()
{
}
//
//
// implementazione che gestira' la richiesta ed eventualmente produrra' la risposta:
IChainCommand * CommandRequest_XX_X::handler(AbstractHeaderMessage *header, ClientContainer *clientRequest)
{
    ClientContainer         *client = (ClientContainer*)clientRequest; // non necessario provvedere alla sua distruzione
    TicTacToeHeader         *ticTacToeHeader = (TicTacToeHeader*)header;
    ISpecializedPlugin      *plugin = client->udpServer->getPlugin();
    Connection              *conn = NULL;
    //
    //TODO: inserire il codice specifico per la gestione di una particolare richiesta
    BodyMessage_80_3        *bodyRequest = NULL;
    ResponseMessage_80_3    *answer = NULL;
    PreparedStatement       *preparedStmt = NULL;
    ResultSet               *ret = NULL;
    boolean                 requestThruUDP = client->infoTcpClient == NULL;

    try {
        bodyRequest = new BodyMessage_80_3(client->buffer);
        answer = new ResponseMessage_80_3(header->GetIDService(), header->GetIDMessage());

        ResponseMessage_100_3   newTextMessageNotification(SERVICE_NOTIFICATION, 3); // invia all'altro utente
        TicTacToeHeader         ticTacToeHeaderNotification;
        ssize_t                 sent = 0;
        TicTacToeData          *slotSender = NULL;

        if (requestThruUDP) // it means request comes from UDP, so we don't have info about socket
            slotSender = (TicTacToeData*)client->tcpServer->findMemorySlot(ticTacToeHeader->GetClientTicket());
        else
            slotSender = (TicTacToeData*)client->infoTcpClient;
        newTextMessageNotification.SetActionIndex(bodyRequest->GetActionIndex());
        if (slotSender)
            ticTacToeHeaderNotification.SetClientTicket(slotSender->networkUserSocket);
        if (ticTacToeHeaderNotification.GetClientTicket() != 0)  // we send notification of our action to the other player
            sent = client->tcpServer->sendMessage(ticTacToeHeaderNotification.GetClientTicket(), &ticTacToeHeaderNotification, &newTextMessageNotification);
        if (sent > 0)
            answer->SetResultCode(retActionDelivered);
        else
            answer->SetResultCode(retErrorDelivery);
    }
    catch (sql::SQLException& ex) {
        if (answer != NULL) answer->SetResultCode(retDatabaseCommunicationError);
        printf("\nError database connection: %s", ex.what());
    }
    catch (...) {
        if (answer != NULL) answer->SetResultCode(retMalformedPacket);
    }
    MemoryUtil::DeleteMemory(&preparedStmt, TRUE);
    MemoryUtil::DeleteMemory(&ret, TRUE);
    plugin->ReleaseConnection(conn); // rilascia la connessione recuperata precedentemente    
    // send back response to sender:
    if (answer != NULL) {
        if (requestThruUDP) // it means request comes from UDP, so we don't have info about socket
            client->tcpServer->sendMessage(ticTacToeHeader->GetClientTicket(), header, answer);
        else
            client->tcpServer->sendMessage(client->infoTcpClient->getSocketId(), header, answer);
    }
    MemoryUtil::DeleteMemory(&bodyRequest, TRUE);
    //
    // -----------------------------------------------------------------------
    MemoryUtil::DeleteMemory(&answer, TRUE);
    return (this);
}
//
//
// ritorna true se service e message coincidono con il command che riesce a gestire
boolean CommandRequest_XX_X::canManage(byte service, byte message)
{
    // TODO: modificare questo test per differenziare il command nella gestione di un servizio e messaggio particolari
    return (service == SERVICE_TICTACTOE_GAME && message == 3);
}
