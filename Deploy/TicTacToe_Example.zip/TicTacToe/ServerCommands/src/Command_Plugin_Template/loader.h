#ifndef LOADER_H
    #define LOADER_H

    #include "IChainCommand.h"
    #include "command.h"
    //
    //
    // Utilizzata solo localmente in questo file, specifica, in base al sistema
    // operativo utilizzato, quale decisione prendere per l'esportazione della funzione.
    #if defined WIN32
        #define LOCAL_ACTION	__declspec(dllexport)
    #elif defined (LINUX)
        #define LOCAL_ACTION	// sotto linux non c' bisogno di estrarre la funzione dalla libreria condivisa
    #endif

    //
    // Punto di ingresso del plugin per il caricamento della classe specializzata.
    // NON MODIFICARE IL NOME DELLA FUNZIONE.
    //
    extern "C" {
        LOCAL_ACTION IChainCommand * createCommand(void);
    }
#endif // LOADER_H
