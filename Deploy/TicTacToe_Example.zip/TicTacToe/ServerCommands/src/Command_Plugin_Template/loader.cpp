
#include "loader.h"

//
//
// chiamata al caricamento dinamico per ritornare oggetto
IChainCommand * createCommand(void)
{
    return (new CommandRequest_XX_X());
}
