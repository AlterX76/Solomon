
#include "command.h"




CommandRequest_XX_X::CommandRequest_XX_X()
{
}
//
//
// implementazione che gestira' la richiesta ed eventualmente produrra' la risposta:
IChainCommand * CommandRequest_XX_X::handler(AbstractHeaderMessage *header, ClientContainer *clientRequest)
{
    ClientContainer     *client = (ClientContainer *) clientRequest; // non necessario provvedere alla sua distruzione
    ConiEnvironment     *objEnv = new ConiEnvironment(new TInfoConn(client->client->GetAddress(), client->client->GetListenPort()), new TInfoConn(0, 0));
    SoftairService      *sender = new SoftairService(NULL);
    ISpecializedPlugin  *plugin = client->server->GetPlugin();
    Connection          *conn = (sql::Connection *) plugin->GetConnection();
    //
    //TODO: inserire il codice specifico per la gestione di una particolare richiesta
    //
    plugin->ReleaseConnection(conn);
    // esegue invio verso il client:
    //sender->SendResponse(objEnv, header, &answer); // non verifica la risposta perche' sara' sempre NULL
    //
    // -----------------------------------------------------------------------
    MemoryUtil::DeleteMemory(&(objEnv->RemoteHost), TRUE);
    MemoryUtil::DeleteMemory(&(objEnv->LocalHost), TRUE);
    MemoryUtil::DeleteMemory(&objEnv, TRUE);
    MemoryUtil::DeleteMemory(&sender, TRUE);
}
//
//
// ritorna true se service e message coincidono con il command che riesce a gestire
boolean CommandRequest_XX_X::canManage(byte service, byte message)
{
    // TODO: modificare questo test per differenziare il command nella gestione di un servizio e messaggio particolari
    return (service == SERVICE_MANAGE_MAP && message == 3);
}
