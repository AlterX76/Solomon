//
//
// TEMPLATE DA UTILIZZARE PER LA CREAZIONE DI UN NUOVO COMMAND DA CARICARE DINAMICAMENTE
#ifndef COMMAND_H
    #define COMMAND_H

    #include <connection.h>
    #include <exception.h>
    #include <prepared_statement.h>
    #include "Solomon.h"
    #include "SolomSmallString.h"
    #include "utility.h"
    #include "AbstractHeaderMessage.h"
    #include "IChainCommand.h"
    #include "connectionpool.h"
    #include "AbstractServerGame.h"
    #include "AbstractTcpServerGame.h"
    #include "BodyMessage_80_2.h"
    #include "ResponseMessage_80_2.h"
    #include "ReturnStatus.h"
    #include "TicTacToeHeader.h"


    using namespace sql;
    using namespace sql::mysql;
    //
    //
    // viene caricata in modalita' dinamica per gestire le richieste inviate dai client:
    class DLL_ACTION CommandRequest_XX_X : public IChainCommand {
        public:
            CommandRequest_XX_X();
            //
            // funzioni virtuali implementate:
            boolean             canManage(byte service, byte message);
            IChainCommand *     handler(AbstractHeaderMessage *header, ClientContainer *clientRequest);
    };

#endif // COMMAND_H
