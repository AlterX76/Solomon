
#include "command.h"
#include "ResponseMessage_100_2.h"
#include "tictactoebridgeprovider.h"
#include "ISpecializedPlugin.h"


CommandRequest_XX_X::CommandRequest_XX_X()
{
}
//
//
IChainCommand * CommandRequest_XX_X::handler(AbstractHeaderMessage *header, ClientContainer *clientRequest)
{
    ClientContainer         *client = (ClientContainer*)clientRequest; // non necessario provvedere alla sua distruzione
    TicTacToeHeader         *ticTacToeHeader = (TicTacToeHeader*)header;
    ISpecializedPlugin      *plugin = client->udpServer->getPlugin();
    Connection              *conn = NULL;
    //
    //TODO: put here your code:
    ResponseMessage_80_2    *answer = NULL;
    PreparedStatement       *preparedStmt = NULL;
    ResultSet               *ret = NULL;
    boolean                 requestThruUDP = client->infoTcpClient == NULL;

    printf("\n------- NEW COMMAND CHANGE 80.2 -------\n");
    fflush(stdout);
    try {
        answer = new ResponseMessage_80_2(header->GetIDService(), header->GetIDMessage());
        conn = (sql::Connection *)plugin->GetConnection(); // recupera connessione verso il database
        conn->setAutoCommit(TRUE);
        preparedStmt = conn->prepareStatement("call sp_joinout(?)");
        preparedStmt->setString(1, SQLString((const char*)ticTacToeHeader->GetSessionToken()));
        ret = preparedStmt->executeQuery();
        if (ret->next()) {
            TicTacToeData  *slotSender = NULL;

            if (requestThruUDP) // it means request comes from UDP, so we don't have info about socket
                slotSender = (TicTacToeData*)client->tcpServer->findMemorySlot(ticTacToeHeader->GetClientTicket());
            else
                slotSender = (TicTacToeData*)client->infoTcpClient;
            if (slotSender) slotSender->SessionTokenID = "";
            if (ret->getInt(1) != 0) { // valid socket: we send close notification to other player
                ResponseMessage_100_2   closeChatNotification(SERVICE_NOTIFICATION, 2); // invia all'altro utente
                TicTacToeHeader         ticTacToeHeaderNotification;
                TicTacToeData           *slotReceiver = (TicTacToeData*)client->tcpServer->findMemorySlot(ret->getInt(1)); // get information about other player

                closeChatNotification.SetResultCode(retGameClosed);
                ticTacToeHeaderNotification.SetClientTicket(ret->getInt(1));
                if (slotReceiver && ticTacToeHeaderNotification.GetClientTicket() != 0)
                    client->tcpServer->sendMessage(slotReceiver->getSslSocket(), ticTacToeHeaderNotification.GetClientTicket(), &ticTacToeHeaderNotification, &closeChatNotification);
            }
            answer->SetResultCode(retLogoutExecuted);
        }
        else
            answer->SetResultCode(retErrorRetryLater);
    }
    catch (sql::SQLException& ex) {
        if (answer != NULL) answer->SetResultCode(retDatabaseCommunicationError);
        printf("\nError database connection: %s", ex.what());
    }
    catch (...) {
        if (answer != NULL) answer->SetResultCode(retMalformedPacket);
    }
    MemoryUtil::DeleteMemory(&preparedStmt, TRUE);
    MemoryUtil::DeleteMemory(&ret, TRUE);
    plugin->ReleaseConnection(conn); // rilascia la connessione recuperata precedentemente    
    // send back response to sender:
    if (answer != NULL) {
        if (requestThruUDP) // it means request comes from UDP, so we don't have info about socket
            client->tcpServer->sendMessage(client->infoTcpClient->getSslSocket(), ticTacToeHeader->GetClientTicket(), header, answer);
        else
            client->tcpServer->sendMessage(client->infoTcpClient->getSslSocket(), client->infoTcpClient->getSocketId(), header, answer);
    }
    //
    // -----------------------------------------------------------------------
    MemoryUtil::DeleteMemory(&answer, TRUE);
    return (this);
}
//
//
// ritorna true se service e message coincidono con il command che riesce a gestire
boolean CommandRequest_XX_X::canManage(byte service, byte message)
{
    // TODO: modificare questo test per differenziare il command nella gestione di un servizio e messaggio particolari
    return (service == SERVICE_TICTACTOE_GAME && message == 2);
}
