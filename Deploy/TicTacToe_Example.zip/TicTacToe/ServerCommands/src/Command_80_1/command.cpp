
#include "command.h"
#include "ResponseMessage_100_1.h"
#include "tictactoebridgeprovider.h"
#include "ISpecializedPlugin.h"


CommandRequest_XX_X::CommandRequest_XX_X()
{
}
//
//
// command to manage request 80.1 (player login):
IChainCommand * CommandRequest_XX_X::handler(AbstractHeaderMessage *header, ClientContainer *clientRequest)
{
    ClientContainer         *client = (ClientContainer *)clientRequest; // non necessario provvedere alla sua distruzione
    TicTacToeHeader         *ticTacToeHeader = (TicTacToeHeader*)header;
    ISpecializedPlugin      *plugin = client->udpServer->getPlugin();
    Connection              *conn = NULL;
    //
    //TODO: put here your code (this command can manage requests coming from either UDP and TCP protocols):
    BodyMessage_80_1        *bodyRequest = NULL;
    ResponseMessage_80_1    *answer = NULL;
    PreparedStatement       *preparedStmt = NULL;
    ResultSet               *ret = NULL;
    buffer_pointer          ptrLoginSession = client->tcpServer->createUniqueSessionToken(); // unique random number: caller is responsible of memory deallocation
    string                  login_session = ptrLoginSession;
    boolean                 requestThruUDP = client->infoTcpClient == NULL;

    try {
        bodyRequest = new BodyMessage_80_1(client->buffer);
        answer = new ResponseMessage_80_1(header->GetIDService(), header->GetIDMessage());
        if (bodyRequest->GetNickname().length() <= 4)
            answer->SetResultCode(retTooShortNickname);
        else if (bodyRequest->GetNickname().length() > 25)
            answer->SetResultCode(retTooLongNickname);
        else {
            conn = (sql::Connection *)plugin->GetConnection(); // recupera connessione verso il database
            conn->setAutoCommit(TRUE);
            preparedStmt = conn->prepareStatement("call sp_ticTacToeJoin(?,?,?)");
            preparedStmt->setString(1, SQLString(login_session));
            if (requestThruUDP) // it means request comes from UDP, so we don't have info about socket
                preparedStmt->setInt(2, ticTacToeHeader->GetClientTicket());
            else // request comes from TCP, so we can use variable in if() case
                preparedStmt->setInt(2, client->infoTcpClient->getSocketId());
            preparedStmt->setString(3, bodyRequest->GetNickname().c_str());
            ret = preparedStmt->executeQuery();
            if (ret->next()) {
                if (ret->getInt(1) == 1) { // player successfully tracked in DB
                    TicTacToeData  *slotSender = NULL;
                    TicTacToeData  *slotReceiver = NULL;

                    if (requestThruUDP) // it means request comes from UDP, so we don't have info about socket
                        slotSender = (TicTacToeData*)client->tcpServer->findMemorySlot(ticTacToeHeader->GetClientTicket()); // socket provided by our protocol
                    else // request comes from TCP, so we can use variable in if() case
                        slotSender = (TicTacToeData*)client->infoTcpClient;
                    if (slotSender) slotSender->SessionTokenID = login_session; // we convert slot in our custom object and track our session
                    answer->SetSessionToken(login_session);
                    if (ret->getInt(2) == 0) { // player is tracked in database, but in WAIT for another player
                        if (slotSender) slotSender->performFirstAction.set(1); // this guy will start with first action game
                        answer->SetResultCode(retNoErrorWait);
                        answer->SetFirstActionInGame(1);
                    }
                    else { // player tracked in database, and in GAME
                        ResponseMessage_100_1   startChatNotification(SERVICE_NOTIFICATION, 1); // notification to alert the other player
                        TicTacToeHeader         ticTacToeHeaderNotification;

                        if (slotSender) slotSender->networkUserSocket = ret->getInt(2); // we set socket of the other player
                        slotReceiver = (TicTacToeData*)client->tcpServer->findMemorySlot(ret->getInt(2)); // get information about other player
                        if (slotReceiver) slotReceiver->networkUserSocket = ticTacToeHeader->GetClientTicket(); // set our own socket to other player
                        answer->SetResultCode(retNoErrorGame);
                        answer->SetNickname(ret->getString(4));
                        ticTacToeHeaderNotification.SetSessionToken(ret->getString(3));
                        ticTacToeHeaderNotification.SetClientTicket(ret->getInt(2));
                        startChatNotification.SetResultCode(retNoErrorGame);
                        startChatNotification.SetNickname(bodyRequest->GetNickname());
                        if (ticTacToeHeaderNotification.GetClientTicket() != 0) // send to the other player (check to be sure we are not sending to ourselves)
                            client->tcpServer->sendMessage(ticTacToeHeaderNotification.GetClientTicket(), &ticTacToeHeaderNotification, &startChatNotification);
                    }
                }
                else {
                    answer->SetResultCode(retErrorDuplicateEntry);
                }
            }
            else
                answer->SetResultCode(retDatabaseCommunicationError);
        }
    }
    catch (sql::SQLException& ex) {
        if (answer != NULL) answer->SetResultCode(retDatabaseCommunicationError);
        printf("\nError database connection: %s", ex.what());
    }
    catch (...) {
        if (answer != NULL) answer->SetResultCode(retMalformedPacket);
    }
    MemoryUtil::DeleteMemory(&ptrLoginSession, FALSE);
    MemoryUtil::DeleteMemory(&preparedStmt, TRUE);
    MemoryUtil::DeleteMemory(&ret, TRUE);
    plugin->ReleaseConnection(conn); // release used connection
    // send back response to sender:
    if (answer != NULL)
        if (requestThruUDP) // it means request comes from UDP, so we don't have info about socket
            client->tcpServer->sendMessage(ticTacToeHeader->GetClientTicket(), header, answer);
        else // request comes from TCP, so we can use variable in if() case
            client->tcpServer->sendMessage(client->infoTcpClient->getSocketId(), header, answer);
    MemoryUtil::DeleteMemory(&bodyRequest, TRUE);
    //
    // -----------------------------------------------------------------------
    MemoryUtil::DeleteMemory(&answer, TRUE);
    return (this);
}
//
//
// true if this command is able to manage service=80 and message=1
boolean CommandRequest_XX_X::canManage(byte service, byte message)
{
    return (service == SERVICE_TICTACTOE_GAME && message == 1);
}
