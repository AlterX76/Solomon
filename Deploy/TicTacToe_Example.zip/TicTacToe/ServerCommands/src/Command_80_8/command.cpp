
#include "command.h"
#include "tictactoebridgeprovider.h"
#include <cstdio>
#include "ISpecializedPlugin.h"


CommandRequest_XX_X::CommandRequest_XX_X()
{
}
//
//
// implementazione che gestira' la richiesta ed eventualmente produrra' la risposta:
IChainCommand * CommandRequest_XX_X::handler(AbstractHeaderMessage *header, ClientContainer *clientRequest)
{
    ClientContainer         *client = (ClientContainer*)clientRequest; // non necessario provvedere alla sua distruzione 
    ISpecializedPlugin      *plugin = client->udpServer->getPlugin();
    TicTacToeHeader         *ticTacToeHeader = (TicTacToeHeader*)header;
    Connection              *conn = NULL;
    //
    //TODO: inserire il codice specifico per la gestione di una particolare richiesta
    BodyMessage_80_8        *bodyRequest;
    PreparedStatement       *preparedStmt = NULL;
    ResultSet               *ret = NULL;

    try {
        bodyRequest = new BodyMessage_80_8(client->buffer);
        std::string pwd = (buffer_pointer)bodyRequest->GetTrustedPassword();
        if (strncmp(pwd.c_str(), plugin->GetTrustedPassword(), pwd.length()) == 0) { // check to be sure request is coming from within server
            conn = (sql::Connection *)plugin->GetConnection(); // gets DB connection
            conn->setAutoCommit(TRUE);
            preparedStmt = conn->prepareStatement("call sp_pendingSocket(?)");
            preparedStmt->setString(1, SQLString((const buffer_pointer)ticTacToeHeader->GetSessionToken()));
            ret = preparedStmt->executeQuery();
        }
    }
    catch (...) {
    }
    MemoryUtil::DeleteMemory(&preparedStmt, TRUE);
    MemoryUtil::DeleteMemory(&ret, TRUE);
    plugin->ReleaseConnection(conn); // rilascia la connessione recuperata precedentemente    
    //
    // -----------------------------------------------------------------------
    return (this);
}
//
//
// ritorna true se service e message coincidono con il command che riesce a gestire
boolean CommandRequest_XX_X::canManage(byte service, byte message)
{
    // TODO: modificare questo test per differenziare il command nella gestione di un servizio e messaggio particolari
    return (service == SERVICE_TICTACTOE_GAME && message == 8);
}
