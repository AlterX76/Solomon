SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';


-- -----------------------------------------------------
-- Table `TicTacToe`.`Player`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `TicTacToe`.`Player` (
  `login_session` VARCHAR(40) NOT NULL DEFAULT 0 COMMENT 'it is a copy to avoid a join on the other table' ,
  `idSocket` INT NOT NULL DEFAULT 0 COMMENT 'socket id sul server\nper le sue comunicazioni' ,
  `Nickname` VARCHAR(25) NULL COMMENT 'it will stored only to avoid a join with UserInfo table.' ,
  `connected_login_session` VARCHAR(40) NOT NULL DEFAULT '' ,
  `connected_idSocket` INT UNSIGNED NOT NULL DEFAULT 0 ,
  `RegistrationDate` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ,
  PRIMARY KEY (`login_session`) ,
  INDEX `fk_Player_Player_idx` (`connected_login_session` ASC) ,
  CONSTRAINT `fk_Player_Player`
    FOREIGN KEY (`connected_login_session` )
    REFERENCES `TicTacToe`.`Player` (`login_session` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'It contains players in the map and all informations like geo /* comment truncated */ /*-position, status, enemy or mate ecc...*/';


-- -----------------------------------------------------
-- procedure sp_updatePosition
-- -----------------------------------------------------

DELIMITER $$
USE `TicTacToe`$$
CREATE DEFINER=`TicTacToe`@`176.58.90.215` PROCEDURE `sp_updatePosition`(loginSession VARCHAR(40), newLatitude DOUBLE, newLongitude DOUBLE)
BEGIN
	DECLARE retSock INT DEFAULT 0;

	UPDATE Player SET Latitude = newLatitude, Longitude = newLongitude WHERE login_session = loginSession;
	SELECT ROW_COUNT() INTO @retSock;
	IF @retSock = 1 THEN
		set @retSock = sp_getMatchedPlayerSocket(loginSession); -- recupera socket dell'altro interlocutore
	END IF;
	SELECT @retSock, newLatitude, newLongitude;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure sp_joinout
-- -----------------------------------------------------

DELIMITER $$
USE `TicTacToe`$$
CREATE DEFINER=`TicTacToe`@`176.58.90.215` PROCEDURE `sp_joinout`(loginSession VARCHAR(40))
BEGIN
	DECLARE updated INT DEFAULT 0;
	DECLARE sockMatched INT DEFAULT 0;
	--
	-- elimina l'utente dalla mappa in cui sta giocando:
	DELETE FROM Player WHERE login_session = loginSession;
	SELECT ROW_COUNT() INTO @updated;
	IF @updated = 1 THEN -- e' riuscito ad eliminare il player
		-- recupera eventuale player in chat con il player da cancellare:		
		SET @sockMatched = sp_getMatchedPlayerSocket(loginSession);
		DELETE FROM Player WHERE connected_login_session = loginSession;
	END IF;
	SELECT @sockMatched;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure sp_ticTacToeJoin
-- -----------------------------------------------------

DELIMITER $$
USE `TicTacToe`$$
CREATE DEFINER=`tictactoe`@`176.58.90.215` PROCEDURE `sp_ticTacToeJoin`(session_token VARCHAR(40), sock INT, nick VARCHAR(25))
BEGIN
	DECLARE sessionTokenMatched VARCHAR(40);
	DECLARE idSocketMatched INT DEFAULT 0;
	DECLARE nicknameMatched VARCHAR(25) DEFAULT "";
	DECLARE waiting INT;
	DECLARE inserted INT DEFAULT 0;
	-- 
	set @sessionTokenMatched = session_token;
	call sp_findFirstPerson(@sessionTokenMatched, @idSocketMatched, @nicknameMatched);
	IF STRCMP(@sessionTokenMatched, '') != 0 THEN  -- FOUND A PLAYER
		SET @waiting = 0;
		START TRANSACTION;
		UPDATE Player 
		SET Waiting = 0, connected_login_session = session_token, connected_idSocket = sock 
		WHERE login_session = @sessionTokenMatched AND idSocket = @idSocketMatched;
	ELSE
		SET @waiting = 1;
		SET @sessionTokenMatched = 0;
	END IF;
	-- 
	-- INSERISCE PLAYER
	INSERT INTO Player (login_session
						, idSocket					
						, Nickname
						, Waiting
						, connected_login_session
						, connected_idSocket)
	VALUES (
		session_token
		, sock
		, nick
		, @waiting
		, @sessionTokenMatched
		, @idSocketMatched
	);	
	SELECT ROW_COUNT() INTO @inserted;
	IF STRCMP(@sessionTokenMatched, '') != 0 THEN 
		IF @inserted = 1 THEN -- successo!
			COMMIT;
		ELSE
			ROLLBACK;
		END IF;
	END IF;
	-- 
	-- IMPLEMENTAZIONE BLOCCO 4.
	SELECT @inserted, @idSocketMatched, @sessionTokenMatched, @nicknameMatched; 
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure sp_findFirstPerson
-- -----------------------------------------------------

DELIMITER $$
USE `TicTacToe`$$
CREATE DEFINER=`tictactoe`@`176.58.90.215` PROCEDURE `sp_findFirstPerson`(INOUT session_token VARCHAR(40), OUT sock INT, OUT nick VARCHAR(25))
BEGIN
	declare sessionTokenMatched VARCHAR(40) DEFAULT '';
	declare selected INT;
	declare socketMatched INT DEFAULT 0;
    declare nickMatched VARCHAR(30) default '';
    
	SELECT dest.login_session, dest.idSocket, dest.Nickname
	INTO @sessionTokenMatched, @socketMatched, @nickMatched
    FROM Player dest 
    WHERE dest.Waiting = 1 AND dest.login_session != session_token LIMIT 1;

	SELECT FOUND_ROWS() INTO @selected;
	IF @selected = 0 THEN -- no player found
		SET session_token = '';
		SET sock =  0;
	ELSE
		-- to avoid to lose session_token, we set here:
		SET session_token = @sessionTokenMatched;
        set nick = @nickMatched;
        set sock = @socketMatched;
	END IF;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- function sp_getPlayerSocket
-- -----------------------------------------------------

DELIMITER $$
USE `TicTacToe`$$
CREATE DEFINER=`TicTacToe`@`176.58.90.215` FUNCTION `sp_getPlayerSocket` (sessionToken VARCHAR(40)) RETURNS INT(11)
	DETERMINISTIC
BEGIN
	DECLARE retSock INT DEFAULT 0;
	DECLARE selected INT;

	SELECT idSocket INTO @retSock FROM Player WHERE login_session = sessionToken;
	SELECT FOUND_ROWS() INTO @selected;
	IF @selected = 0 THEN
		set @retSock = 0;
	END IF;
	return @retSock;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- function sp_getMatchedPlayerSocket
-- -----------------------------------------------------

DELIMITER $$
USE `TicTacToe`$$
CREATE DEFINER=`TicTacToe`@`176.58.90.215` FUNCTION `sp_getMatchedPlayerSocket`(sessionToken VARCHAR(40)) RETURNS int(11)
    DETERMINISTIC
BEGIN
	DECLARE retSock INT DEFAULT 0;
	DECLARE result INT;

	SELECT idSocket INTO @retSock FROM Player WHERE connected_login_session = sessionToken;
	SELECT FOUND_ROWS() INTO @result;
	IF @result = 0 THEN
		set @retSock = 0;
	END IF;
	return @retSock;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure sp_removeNoActiveUsers
-- -----------------------------------------------------

DELIMITER $$
USE `TicTacToe`$$
CREATE DEFINER=`TicTacToe`@`176.58.90.215` PROCEDURE `sp_removeNoActiveUsers`(hours INT)
BEGIN
	DELETE FROM Player 	
	WHERE DATE(RegistrationDate) < DATE_SUB(CURRENT_DATE(), INTERVAL hours HOUR);
	SELECT ROW_COUNT() AS DELETED;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure sp_pendingSocket
-- -----------------------------------------------------

DELIMITER $$
USE `TicTacToe`$$
CREATE DEFINER=`TicTacToe`@`176.58.90.215` PROCEDURE `sp_pendingSocket`(loginSession VARCHAR(40))
BEGIN
	--
	-- elimina l'utente dal database:
	DELETE FROM Player WHERE login_session = loginSession;
END$$

DELIMITER ;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
