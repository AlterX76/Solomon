#ifndef CONNECTIONPOOL_H
    #define CONNECTIONPOOL_H

    #include "Solomon.h"
    #include "MemorySupport.h"
    #include <mysql_driver.h>
    #include <mysql_connection.h>
    #include <queue>

    using namespace std;
    using namespace sql;
    using namespace sql::mysql;
    //
    // pool di connessioni verso il database mysql (usa mysql connector c++)'
    // Utilizza coda per la disponibilita' delle connessioni attive; in caso la coda sia vuota, crea una nuova connessione
    // che poi verra' inserita nella coda; in questo modo il numero di connessioni create sara' proporzionato all'effettivo
    // utilizzo che ne viene fatto sotto carico.
    class DLL_ACTION ConnectionPool {
        private:
            MySQL_Driver                *mysqlDriver; // driver mysql: unico per tutte le connessioni
            queue<sql::Connection *>    *connQueue; // coda usata per la memorizzazione delle connessioni aperte
            pthread_mutex_t             syncQueue; // usata per sincronizzare la coda nelle operazioni di inserimento ed estrazione
            static ConnectionPool       *internalPool;
            static string               connectionString;
            static string               username;
            static string               password;
            static u_short              connectionTimeout;
            //
            // costruttore privato:
            ConnectionPool();
            //
            // interne:
            void                        LockQueue(pthread_mutex_t *mutex);
            void                        UnlockQueue(pthread_mutex_t *mutex);

        public:
            ~ConnectionPool();

            static ConnectionPool *     createPool(buffer_pointer connectionString, buffer_pointer username, buffer_pointer password, u_short connTimeout); // crea pool di connessioni
            static void                 disposeConnectionPool(); // chiude tutte le connessioni e rilascia la memoria
            //
            // funzioni di gestione della classe:
            Connection *                extractConnection(); // recupera connessione o da coda o nuova
            void                        releaseConnection(Connection *conn); // inserisce la connessione nella coda
    };

#endif // CONNECTIONPOOL_H
