
#include "Template.h"
#include "MyPlugin.h"



class MyPlugin *myEngine = NULL;

//
// Entry point for the plug-in responsible for the creation of plugin object.
//
ISpecializedPlugin * PluginEntryPoint(TConfigParameters *params)
{
    myEngine = new MyPlugin(params);
	return (myEngine);
}
