// Template.cpp : Defines the initialization routines for the DLL.
//

#include "Template.h"
#include "MyPlugin.h"



class MyPlugin *myEngine = NULL;

//
// Punto di ingresso del plugin per il caricamento della classe specializzata.
// La funzione si occuper� della creazione dell'oggetto specializzato che erediter�
// dalla classe ISpecializedMulticast.
//
ISpecializedPlugin * PluginEntryPoint(TConfigParameters *params)
{
    myEngine = new MyPlugin(params);
	return (myEngine);
}
