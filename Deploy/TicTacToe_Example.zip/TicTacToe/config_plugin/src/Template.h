// Template.h : main header file for the Template DLL
//
//
// Fare riferimento a questo file per la specializzazione della classe:
#include "ISpecializedPlugin.h"
#include "PluginLoader.h"
//
//
// Utilizzata solo localmente in questo file, specifica, in base al sistema
// operativo utilizzato, quale decisione prendere per l'esportazione della funzione.
#if defined (WIN32)
	#define LOCAL_ACTION	__declspec(dllexport)
#elif defined (LINUX)
	#define LOCAL_ACTION	// sotto linux non c'� bisogno di estrarre la funzione dalla libreria condivisa
#endif

//
// Punto di ingresso del plugin per il caricamento della classe specializzata.
// NON MODIFICARE IL NOME DELLA FUNZIONE.
//
extern "C" {
    LOCAL_ACTION ISpecializedPlugin * PluginEntryPoint(TConfigParameters *params);
}
