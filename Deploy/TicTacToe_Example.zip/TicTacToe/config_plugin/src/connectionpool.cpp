#include "connectionpool.h"

//
// inizializza la variabile statica altrimenti non compila!
ConnectionPool * ConnectionPool::internalPool = NULL;
string ConnectionPool::username;
string ConnectionPool::password;
string ConnectionPool::connectionString;
u_short ConnectionPool::connectionTimeout;


ConnectionPool::ConnectionPool()
{
    // inizializza la coda:
    this->connQueue = new queue<Connection *>();
    // inizializza il driver per la connessione al database:
    this->mysqlDriver = get_mysql_driver_instance();
    //
    // inizializza il mutex:
    #if defined LINUX
        pthread_mutex_init(&this->syncQueue, NULL);
    #else
        InitializeCriticalSection(&this->syncQueue);
    #endif
}


ConnectionPool::~ConnectionPool()
{
#if defined LINUX
    pthread_mutex_destroy(&this->syncQueue);
#else
    DestroyCriticalSection(&this->syncQueue);
#endif
    //
    // DISTRUGGERE LE CONNESSIONI NELLA CODA!!!
    Connection  *tmp = NULL;

    while (!this->connQueue->empty()) {
        tmp = this->connQueue->front(); // recupera l'elemento
        tmp->close(); // chiude la connessine
        this->connQueue->pop(); // lo elimina dalla coda
        MemoryUtil::DeleteMemory(&tmp, TRUE);
    }
    MemoryUtil::DeleteMemory(&this->connQueue, TRUE);
}
//
// Implementazione singleton pattern
// TO BE NOT USED IN MULTI-THREADING ENV
ConnectionPool * ConnectionPool::createPool(buffer_pointer connectionString, buffer_pointer username, buffer_pointer password, u_short connTimeout)
{
    if (ConnectionPool::internalPool == NULL) {
        ConnectionPool::connectionString = connectionString;
        ConnectionPool::username = username;
        ConnectionPool::password = password;
        ConnectionPool::connectionTimeout = connTimeout;
        ConnectionPool::internalPool = new ConnectionPool(); // crea nuovo oggetto
    }
    return (ConnectionPool::internalPool);
}
//
// Estrae o crea connessione con auto commit disabilitato e transaction isolation su TRANSACTION_READ_COMMITTED
Connection * ConnectionPool::extractConnection()
{
    Connection          *tmp = NULL;
    ConnectOptionsMap   options;

    /*
    this->LockQueue(&this->syncQueue);
    if (this->connQueue->empty() == false) { // se la coda non e' vuota estrae una connessione
        tmp = this->connQueue->front(); // prende la connessione
        this->connQueue->pop(); // estrae l'oggetto dalla coda
    }
    this->UnlockQueue(&this->syncQueue);
    */
    if (tmp == NULL) { // puntatore nullo: crea una nuova connessione perche' coda vuota
        options["hostName"] = ConnectionPool::connectionString;
        options["userName"] = ConnectionPool::username;
        options["password"] = ConnectionPool::password;
        options["OPT_CONNECT_TIMEOUT"] = ConnectionPool::connectionTimeout;
        tmp = this->mysqlDriver->connect(options);
    }
    //tmp->setClientOption("MYSQL_OPT_TIMEOUT", (const void *)&ConnectionPool::connectionTimeout);
    tmp->setAutoCommit(FALSE);
    tmp->setTransactionIsolation(TRANSACTION_REPEATABLE_READ);
    return (tmp);
}


void ConnectionPool::releaseConnection(Connection *conn)
{
    if (conn != NULL) {
        conn->close();
        MemoryUtil::DeleteMemory(&conn, TRUE);
        /*
        this->LockQueue(&this->syncQueue);
        this->connQueue->push(conn);
        this->UnlockQueue(&this->syncQueue);
        */
    }
}

void ConnectionPool::disposeConnectionPool()
{
    MemoryUtil::DeleteMemory(&ConnectionPool::internalPool, TRUE);
}


void ConnectionPool::LockQueue(pthread_mutex_t *mutex)
{
#if defined (WIN32)
    EnterCriticalSection(mutex);
#elif defined (LINUX)
    pthread_mutex_lock(mutex);
#endif
}


void ConnectionPool::UnlockQueue(pthread_mutex_t *mutex)
{
#if defined (WIN32)
    LeaveCriticalSection(mutex);
#elif defined (LINUX)
    pthread_mutex_unlock(mutex);
#endif
}
