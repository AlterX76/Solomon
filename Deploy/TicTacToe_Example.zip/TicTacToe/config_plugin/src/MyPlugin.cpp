

#include "MyPlugin.h"




MyPlugin::MyPlugin(TConfigParameters *params) :
    m_params(params)
{
    this->m_pool = ConnectionPool::createPool((buffer_pointer)this->m_params->m_dns.get(), (buffer_pointer)this->m_params->m_username.get()
                                              , (buffer_pointer)this->m_params->m_password.get(), this->m_params->m_connTimeout);
}


MyPlugin::~MyPlugin()
{
    ConnectionPool::disposeConnectionPool();
}


void * MyPlugin::GetConnection(void)
{
    return (this->m_pool->extractConnection());
}

void MyPlugin::ReleaseConnection(void *conn)
{
    this->m_pool->releaseConnection((Connection *) conn);
}


TInfoConnection * MyPlugin::GetServerInfo(void)
{ 
    return (this->m_params->m_serverInfo);
}

u_short	MyPlugin::GetWorkersNumber(void) 
{ 
    return (this->m_params->m_workerThreadNumber);
}

u_short	MyPlugin::GetPoolThreadsNumber(void) 
{ 
    return (this->m_params->m_poolThreadsNumber);
}

u_short MyPlugin::GetMaxSecsToCloseInactiveConn()
{
    return (this->m_params->m_secsInactiveConnection);
}

u_short MyPlugin::GetSecondsToStartGarbage()
{
    return (this->m_params->m_intervalGarbage);
}

buffer_pointer MyPlugin::GetCommandsPath(void)
{
    return ((buffer_pointer)this->m_params->m_commandsPath.get());
}

buffer_pointer MyPlugin::GetSystemUploadRoot()
{
    return ((buffer_pointer)this->m_params->m_systemUploadRoot.get());
}

buffer_pointer MyPlugin::GetLinkDownloadRoot()
{
    return ((buffer_pointer)this->m_params->m_linkDownloadRoot.get());
}

buffer_pointer MyPlugin::GetTrustedPassword()
{
    return ((buffer_pointer)this->m_params->m_internalTrustedPassswd.get());
}

boolean MyPlugin::GetPermissionToUploadFile()
{
    return (this->m_params->m_permissionToUploadFile);
}

u_longer MyPlugin::GetMaxBytesFileUpload()
{
    return (this->m_params->m_maxSizeBytesFile);
}
