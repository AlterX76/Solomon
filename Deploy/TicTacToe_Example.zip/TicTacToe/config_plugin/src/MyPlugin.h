//
//
// Specialization for the plug-in

#ifndef _MY_PLUGIN_H

	#define _MY_PLUGIN_H

	#define	FALSE	0
	#define TRUE	!(FALSE)

	//
    // Public interface to be exposed
    #include "ISpecializedPlugin.h"
    #include "PluginLoader.h"
	//
    // general purposes:
    #include "MemorySupport.h"
    #include "DataContainerReader.h"
    #include "Structures.h"
    #include "SolomStringBuffer.h"
	//
    // -------------------- CUSTOM HEADER FILES -----------------------------
    //
    #include "connectionpool.h"
    #include <mysql_connection.h>
	// ----------------------------------------------------------------------------------------------------------------
	//
    // Our plugin specialized for mysql connection and plugin configuration xml:
	class MyPlugin : public ISpecializedPlugin {
		private:			
            TConfigParameters   *m_params;
            ConnectionPool      *m_pool;

		public:
			//
			// Costruttore/Distruttore:		
            MyPlugin(TConfigParameters *params);
			~MyPlugin();
            //
            // connection pool:
            void *              GetConnection(void);
            void                ReleaseConnection(void *conn);
            //
            // Funzioni per la gestione del server:
            TInfoConnection *   GetServerInfo(void);
            u_short             GetWorkersNumber(void);
            u_short             GetPoolThreadsNumber(void);
            u_short             GetMaxSecsToCloseInactiveConn();
            u_short             GetSecondsToStartGarbage();
            buffer_pointer      GetCommandsPath(void);
            buffer_pointer      GetSystemUploadRoot(void);
            buffer_pointer      GetLinkDownloadRoot(void);
            buffer_pointer      GetTrustedPassword(void);
            boolean             GetPermissionToUploadFile();
            u_longer            GetMaxBytesFileUpload();
            //
            // Funzioni per il caricamento dei commands per la gestione delle richieste ricevute dal server:

	};


#endif // _MY_PLUGIN_H

	
