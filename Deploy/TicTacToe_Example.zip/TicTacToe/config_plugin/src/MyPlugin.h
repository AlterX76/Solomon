
//
//
// Dichiarazione della classe che conterr� la specializzazione per il plugin.

#ifndef _MY_PLUGIN_H

	#define _MY_PLUGIN_H

	#define	FALSE	0
	#define TRUE	!(FALSE)

	//
	// Interfaccia che il plugin deve esporre per essere caricata in modo corretto:
    #include "ISpecializedPlugin.h"
    #include "PluginLoader.h"
	//
	// inclusioni per il funzionamento delle informazioni reperite:
    #include "MemorySupport.h"
    #include "DataContainerReader.h"
    #include "Structures.h"
    #include "SolomStringBuffer.h"
	//
	// -------------------- AGGIUNGERE QUI GLI HEADER PER LA PERSONALIZZAZIONE DEL PLUGIN -----------------------------
    //
    #include "connectionpool.h"
    #include <mysql_connection.h>
	// ----------------------------------------------------------------------------------------------------------------
	//
	// Plugin che eredita dall'interfaccia di specializzazione per il multicast:
	class MyPlugin : public ISpecializedPlugin {
		private:			
            TConfigParameters   *m_params;
            ConnectionPool      *m_pool;

		public:
			//
			// Costruttore/Distruttore:		
            MyPlugin(TConfigParameters *params);
			~MyPlugin();
            //
            // connection pool:
            void *              GetConnection(void);
            void                ReleaseConnection(void *conn);
            //
            // Funzioni per la gestione del server:
            TInfoConnection *   GetServerInfo(void);
            u_short             GetWorkersNumber(void);
            u_short             GetPoolThreadsNumber(void);
            u_short             GetMaxSecsToCloseInactiveConn();
            u_short             GetSecondsToStartGarbage();
            buffer_pointer      GetCommandsPath(void);
            buffer_pointer      GetSystemUploadRoot(void);
            buffer_pointer      GetLinkDownloadRoot(void);
            buffer_pointer      GetTrustedPassword(void);
            boolean             GetPermissionToUploadFile();
            boolean             GetKeepConnectionPermanent();
            boolean             GetHotLoadPluginState();
            u_longer            GetMaxBytesFileUpload();
            buffer_pointer      GetSslCertificate();
    };


#endif // _MY_PLUGIN_H

	
