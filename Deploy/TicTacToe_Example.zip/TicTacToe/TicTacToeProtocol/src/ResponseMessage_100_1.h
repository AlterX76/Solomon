


#ifndef _RESPONSE_MESSAGE_100_1_H

    #define _RESPONSE_MESSAGE_100_1_H

    #include "Solomon.h"
    #include "ResponseMessage_80_1.h"
    #include "Types.h"

    using namespace Solomon::Types;


    class DLL_ACTION ResponseMessage_100_1 : public AbstractResponseMessage {
		private:
            SmallString                 nickname;
            Byte                        firstActionInGame; // which player will start with first action when in game
            byte                        idService;
            byte                        idMessage;

            ResponseMessage_100_1& operator=(const ResponseMessage_100_1&);
            ResponseMessage_100_1(const ResponseMessage_100_1&);

		public:
            ResponseMessage_100_1(byte idService, byte idMessage);
            ~ResponseMessage_100_1();

            void						SetNickname(string value);
            const u_buffer_pointer		GetNickname();
            void                        SetFirstActionInGame(byte value);
            byte                        GetFirstActionInGame();
            //
            // virtual functions to provide:
            DataContainerWriter *		GetBodyMessage(void); 
            void						ParseBinary(DataContainerReader *reader);
            AbstractResponseMessage *   CreateResponseObject(DataContainerReader *binary_response);
            byte                        IDService();
            byte                        IDMessage();

	};

#endif // _RESPONSE_MESSAGE_80_1_H
