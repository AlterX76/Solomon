



#include "TicTacToeHeader.h"
#include "MemorySupport.h"



TicTacToeHeader::TicTacToeHeader() : fixedSessionToken(40), id_ticket(0)
{
    // IMPORTANT: using fixed string is very dangerous, because if it is not set, buffer will be less then expected and will result in a crash
    // SOLUTION: if you can't evoid this, make sure fixed string are immediately set in constructor
    SetSessionToken("");
}

TicTacToeHeader::~TicTacToeHeader()
{
}

byte TicTacToeHeader::SizeOfHeader()
{
    return (AbstractHeaderMessage::SizeOfHeader() + sizeof(this->id_ticket) + this->session_token.size());
}


void TicTacToeHeader::ParseReader(DataContainerReader *reader)
{
    if (reader != 0) { // not empty buffer
        this->session_token.readFrom(reader);
        this->fixedSessionToken.setFilledDescription((const buffer_pointer)this->session_token.get());
        reader->Extract(&this->id_ticket);
        AbstractHeaderMessage::ParseReader(reader);
    }
}


void TicTacToeHeader::WriteIn(DataContainerWriter *writer, size_t lenBody)
{
    // session_token:
    this->session_token.writeIn(writer);
    // id socket is useful when you want to use udp so server needs to know who has sent request from
    writer->Put(this->id_ticket);
    AbstractHeaderMessage::WriteIn(writer, lenBody); // same order in the parser function to respect format of bytes
}


void TicTacToeHeader::SetClientTicket(integer value)
{
    this->id_ticket = value;
}

integer TicTacToeHeader::GetClientTicket()
{
    return (this->id_ticket);
}

void TicTacToeHeader::SetSessionToken(string value)
{
    this->fixedSessionToken.setFilledDescription((buffer_pointer)value.c_str()); // if value is less then of container, it will filled up with spaces
    string temp = (char*)this->fixedSessionToken.getFilledDescription();
    this->session_token.set(temp);
}
//
// the caller has responsibility to deallocate the returned buffer
buffer_pointer TicTacToeHeader::GetSessionToken()
{
    std::string     source = (char*)this->fixedSessionToken.getFilledDescription();
    buffer_pointer  dest;

    SolomStringBuffer::replaceAll((const buffer_pointer)source.c_str(), &dest, DEFAULT_CHAR_TO_RPAD, (const buffer_pointer)"");
    return (dest);
}
