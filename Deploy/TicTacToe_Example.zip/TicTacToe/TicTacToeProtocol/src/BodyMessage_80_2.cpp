


#include "BodyMessage_80_2.h"




BodyMessage_80_2::BodyMessage_80_2()
{
}


BodyMessage_80_2::BodyMessage_80_2(DataContainerReader *)
{
}


BodyMessage_80_2::~BodyMessage_80_2()
{
}


byte BodyMessage_80_2::IDService()
{
    return (SERVICE_TICTACTOE_GAME);
}

byte BodyMessage_80_2::IDMessage()
{
    return (2);
}


AbstractResponseMessage * BodyMessage_80_2::CreateResponseObject(DataContainerReader *binary_response)
{
    ResponseMessage_80_2 *ret = new ResponseMessage_80_2(this->IDService(), this->IDMessage());

    if (binary_response != NULL) ret->ParseBinary(binary_response);
	return (ret);
}
//
//
// no content for this request:
DataContainerWriter * BodyMessage_80_2::GetBodyMessage(void)
{
    return (NULL);
}
