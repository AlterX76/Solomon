


#ifndef _BODYMESSAGE_80_1_H

	#define _BODYMESSAGE_80_1_H

    #include "Solomon.h"
    #include "MemorySupport.h"
    #include "DataContainerReader.h"
    #include "DataContainerWriter.h"
    #include "AbstractBodyMessage.h"
	#include "ResponseMessage_80_1.h"
    #include "TicTacToeHeader.h"
    #include "Types.h"
	//
	//
    // Main message to join in wait or play with a user:
    class DLL_ACTION BodyMessage_80_1 : public AbstractBodyMessage {
		private:
            SmallString                 nickname;

		public:
			BodyMessage_80_1();
			BodyMessage_80_1(DataContainerReader *buffer);
            virtual ~BodyMessage_80_1();
			//
            // public methods:
			void						SetNickname(string value);
            string                      GetNickname();
			//
            // virtual functions to provide:
            AbstractResponseMessage *	CreateResponseObject(DataContainerReader *binary_response); // automatically called to obtain a response object
            DataContainerWriter *		GetBodyMessage(void); // automatically called to send object as request
            byte						IDService(void); //  service id
            byte						IDMessage(void); // message id
	};

#endif // _BODYMESSAGE_80_1_H
