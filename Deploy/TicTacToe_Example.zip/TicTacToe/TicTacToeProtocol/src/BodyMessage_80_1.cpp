


#include "BodyMessage_80_1.h"




BodyMessage_80_1::BodyMessage_80_1()
{
}


BodyMessage_80_1::BodyMessage_80_1(DataContainerReader *buffer)
{
    if (buffer)
        this->nickname.readFrom(buffer);
}


BodyMessage_80_1::~BodyMessage_80_1()
{
}


byte BodyMessage_80_1::IDService()
{
    return (SERVICE_TICTACTOE_GAME);
}

byte BodyMessage_80_1::IDMessage()
{
    return (1);
}

void BodyMessage_80_1::SetNickname(string value)
{
    this->nickname.set(value);
}

string BodyMessage_80_1::GetNickname()
{
    return ((buffer_pointer)this->nickname.get());
}


AbstractResponseMessage * BodyMessage_80_1::CreateResponseObject(DataContainerReader *binary_response)
{
	ResponseMessage_80_1 *ret = new ResponseMessage_80_1(this->IDService(), this->IDMessage());

    if (binary_response != NULL) ret->ParseBinary(binary_response);
	return (ret);
}
//
//
// create a new body object, fill it with object's members and return it:
DataContainerWriter * BodyMessage_80_1::GetBodyMessage(void)
{
    DataContainerWriter *bodyStream = this->initBodyStream(this->nickname.size());

    this->nickname.writeIn(bodyStream);
    return (bodyStream);
}
