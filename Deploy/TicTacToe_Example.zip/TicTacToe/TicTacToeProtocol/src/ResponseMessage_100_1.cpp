



#include "ResponseMessage_100_1.h"
#include "MemorySupport.h"


ResponseMessage_100_1::ResponseMessage_100_1(byte idService, byte idMessage) : idService(idService), idMessage(idMessage)
{
}


ResponseMessage_100_1::~ResponseMessage_100_1()
{
}

void ResponseMessage_100_1::SetNickname(string value)
{
    this->nickname.set(value);
}

const u_buffer_pointer ResponseMessage_100_1::GetNickname()
{
    return (this->nickname.get());
}


void ResponseMessage_100_1::SetFirstActionInGame(byte value)
{
    this->firstActionInGame.set(value);
}

byte ResponseMessage_100_1::GetFirstActionInGame()
{
    return (this->firstActionInGame.get());
}


void ResponseMessage_100_1::ParseBinary(DataContainerReader *reader)
{
    if (reader != NULL) {
        reader->Extract(&this->m_result);
        this->nickname.readFrom(reader);
        this->firstActionInGame.readFrom(reader);
    }
}
//
//
// create a new body object, fill it with object's members and return it:
DataContainerWriter * ResponseMessage_100_1::GetBodyMessage(void)
{
    DataContainerWriter *bodyStream = this->initBodyStream(this->nickname.size() + this->firstActionInGame.size() + sizeof(this->m_result));

    bodyStream->Put(this->m_result);
    this->nickname.writeIn(bodyStream);
    this->firstActionInGame.writeIn(bodyStream);
    return (bodyStream);
}
//
// due to it represents itself a response, we return NULL
AbstractResponseMessage *ResponseMessage_100_1::CreateResponseObject(DataContainerReader *)
{
    return (NULL);
}

byte ResponseMessage_100_1::IDService()
{
    return (idService);
}

byte ResponseMessage_100_1::IDMessage()
{
    return (idMessage);
}

