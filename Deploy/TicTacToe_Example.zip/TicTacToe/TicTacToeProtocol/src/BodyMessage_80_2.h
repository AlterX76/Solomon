



#ifndef _BODYMESSAGE_80_2_H

    #define _BODYMESSAGE_80_2_H

	#include "Solomon.h"
	#include "MemorySupport.h"
	#include "DataContainerReader.h"
	#include "DataContainerWriter.h"
    #include "AbstractBodyMessage.h"
    #include "ResponseMessage_80_2.h"
    #include "TicTacToeHeader.h"
	//
	//
    // request to exit from game:
    class DLL_ACTION BodyMessage_80_2 : public AbstractBodyMessage {
		public:
            BodyMessage_80_2();
            BodyMessage_80_2(DataContainerReader *buffer);
            virtual ~BodyMessage_80_2();
			//
            // virtual functions to provide:
			AbstractResponseMessage *	CreateResponseObject(DataContainerReader *binary_response);
            DataContainerWriter *		GetBodyMessage(void);
            byte						IDService(void);
            byte						IDMessage(void);
	};

#endif // _BODYMESSAGE_80_2_H
