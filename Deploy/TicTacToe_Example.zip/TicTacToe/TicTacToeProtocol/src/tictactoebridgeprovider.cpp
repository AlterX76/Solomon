
#ifndef MOBILE_BUILD

#include "tictactoebridgeprovider.h"
#include "BodyMessage_80_8.h"
#include "SolomSmallString.h"
#include "ISpecializedPlugin.h"


TicTacToeData::TicTacToeData() : SessionTokenID(""), networkUserSocket(0)
{
}

TicTacToeBridgeProvider::TicTacToeBridgeProvider()
{
}

TicTacToeBridgeProvider::~TicTacToeBridgeProvider()
{

}

AbstractHeaderMessage *TicTacToeBridgeProvider::createHeaderMessage()
{
    return new TicTacToeHeader(); // return a new instance of your custom header
}

BaseInfoClient *TicTacToeBridgeProvider::createMemorySlot()
{
    return new TicTacToeData(); // return a new instance of custom data object
}
//
// event called when server is going to close the connection: take chance here to queue your clean request message
TPairMessage * TicTacToeBridgeProvider::serverWillCloseConnection(const BaseInfoClient *info)
{
    BodyMessage_80_8    *body = NULL;
    TicTacToeHeader     *header = NULL;
    TPairMessage        *pairForRequest = NULL;
    TicTacToeData       *memorySlot = (TicTacToeData*)info;

    if (memorySlot->SessionTokenID == "") // if empty, there is nothing to clean (e.g. on db or whereever)
        return (NULL);
    pairForRequest = new TPairMessage();
    body = new BodyMessage_80_8();
    header = new TicTacToeHeader();
    header->SetSessionToken(memorySlot->SessionTokenID);
    header->SetClientTicket(memorySlot->getSocketId());
    header->SetIDService(SERVICE_TICTACTOE_GAME);
    header->SetIDMessage(8);
    body->SetTrustedPassword(this->getPlugin()->GetTrustedPassword()); // IMPORTANT: as an internal message, we ensure there is a minimum of security: see releted command
    pairForRequest->header = header;
    pairForRequest->body = body;
    return (pairForRequest);
}
#endif
