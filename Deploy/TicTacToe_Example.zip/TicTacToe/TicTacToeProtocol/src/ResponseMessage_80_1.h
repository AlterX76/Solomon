



#ifndef _RESPONSE_MESSAGE_80_1_H

    #define _RESPONSE_MESSAGE_80_1_H

	#include "Solomon.h"
    #include "SolomSmallString.h"
    #include "AbstractResponseMessage.h"
    #include "Types.h"

    using namespace Solomon::Types;
	//
	//
    // response message with information about status of player:
    class DLL_ACTION ResponseMessage_80_1 : public AbstractResponseMessage {
		private:
            SmallString                 nickname;
            SmallString                 sessionToken;
            Byte                        firstActionInGame; // which player will start with first action when in game
            byte                        idService;
            byte                        idMessage;

            ResponseMessage_80_1& operator=(const ResponseMessage_80_1&);
            ResponseMessage_80_1(const ResponseMessage_80_1&);

		public:
            ResponseMessage_80_1(byte idService, byte idMessage);
            ~ResponseMessage_80_1();

            void						SetNickname(string value);
            const u_buffer_pointer      GetNickname();
            void                        SetSessionToken(string value);
            const u_buffer_pointer      GetSessionToken();
            void                        SetFirstActionInGame(byte value);
            byte                        GetFirstActionInGame();
            //
			// virtual functions to provide:
			DataContainerWriter *		GetBodyMessage(void); 
			void						ParseBinary(DataContainerReader *reader);
            AbstractResponseMessage *   CreateResponseObject(DataContainerReader *binary_response);
            byte                        IDService();
            byte                        IDMessage();
	};

#endif // _RESPONSE_MESSAGE_80_1_H
