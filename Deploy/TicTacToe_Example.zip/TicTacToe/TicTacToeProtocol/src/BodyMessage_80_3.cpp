


#include "BodyMessage_80_3.h"



BodyMessage_80_3::BodyMessage_80_3()
{
}


BodyMessage_80_3::BodyMessage_80_3(DataContainerReader *buffer)
{
    if (buffer)
        this->actionIndex.readFrom(buffer);
}


BodyMessage_80_3::~BodyMessage_80_3()
{
}


byte BodyMessage_80_3::IDService()
{
    return (SERVICE_TICTACTOE_GAME);
}

byte BodyMessage_80_3::IDMessage()
{
    return (3);
}


void BodyMessage_80_3::SetActionIndex(u_short value)
{
    this->actionIndex.set(value);
}

u_short BodyMessage_80_3::GetActionIndex()
{
    return (this->actionIndex.get());
}


AbstractResponseMessage * BodyMessage_80_3::CreateResponseObject(DataContainerReader *binary_response)
{
    ResponseMessage_80_3 *ret = new ResponseMessage_80_3(this->IDService(), this->IDMessage());

    if (binary_response != NULL) ret->ParseBinary(binary_response);
	return (ret);
}
//
//
// create a new body object, fill it with object's members and return it:
DataContainerWriter * BodyMessage_80_3::GetBodyMessage(void)
{
    DataContainerWriter *bodyStream = this->initBodyStream(sizeof(u_short));

    this->actionIndex.writeIn(bodyStream);
    return (bodyStream);
}
