


#include "ResponseMessage_80_3.h"
#include "MemorySupport.h"
#include "DataContainerReader.h"
#include "DataContainerWriter.h"


ResponseMessage_80_3::ResponseMessage_80_3(byte idService, byte idMessage) : idService(idService), idMessage(idMessage)
{
}


ResponseMessage_80_3::~ResponseMessage_80_3()
{
}


void ResponseMessage_80_3::ParseBinary(DataContainerReader *reader)
{    
    if (reader != NULL) {
        reader->Extract(&this->m_result);
    }
}
//
//
// create a new body object, fill it with object's members and return it:
DataContainerWriter * ResponseMessage_80_3::GetBodyMessage(void)
{
    DataContainerWriter *bodyStream = this->initBodyStream(sizeof(this->m_result));

    bodyStream->Put(this->m_result);
    return (bodyStream);
}
//
// due to it represents itself a response, we return NULL
AbstractResponseMessage *ResponseMessage_80_3::CreateResponseObject(DataContainerReader *)
{
    return (NULL);
}

byte ResponseMessage_80_3::IDService()
{
    return (this->idService);
}

byte ResponseMessage_80_3::IDMessage()
{
    return (this->idMessage);
}
