


#include "BodyMessage_80_8.h"




BodyMessage_80_8::BodyMessage_80_8()
{
}


BodyMessage_80_8::BodyMessage_80_8(DataContainerReader *buffer)
{
    if (buffer)
        this->trustedPassword.readFrom(buffer);
}


BodyMessage_80_8::~BodyMessage_80_8()
{
}

void BodyMessage_80_8::SetTrustedPassword(string value)
{
    this->trustedPassword.set(value);
}

const u_buffer_pointer BodyMessage_80_8::GetTrustedPassword()
{
    return (this->trustedPassword.get());
}


byte BodyMessage_80_8::IDService()
{
    return (SERVICE_TICTACTOE_GAME);
}

byte BodyMessage_80_8::IDMessage()
{
    return (8);
}

// no response: this request is internal and contains info to use to clean up
AbstractResponseMessage * BodyMessage_80_8::CreateResponseObject(DataContainerReader *binary_response)
{
    return (NULL);
}
//
//
// create a new body object, fill it with object's members and return it:
DataContainerWriter * BodyMessage_80_8::GetBodyMessage(void)
{
    DataContainerWriter *bodyStream = this->initBodyStream(this->trustedPassword.size());

    this->trustedPassword.writeIn(bodyStream);
    return (bodyStream);
}
