

#include "ResponseMessage_100_2.h"
#include "MemorySupport.h"


ResponseMessage_100_2::ResponseMessage_100_2(byte idService, byte idMessage) : ResponseMessage_80_2(idService, idMessage)
{
}


ResponseMessage_100_2::~ResponseMessage_100_2()
{
}
