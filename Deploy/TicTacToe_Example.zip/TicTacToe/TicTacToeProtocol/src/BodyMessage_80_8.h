


#ifndef _BODYMESSAGE_80_8_H

    #define _BODYMESSAGE_80_8_H

	#include "Solomon.h"
	#include "MemorySupport.h"
	#include "DataContainerReader.h"
	#include "DataContainerWriter.h"
    #include "AbstractBodyMessage.h"
    #include "TicTacToeHeader.h"
    #include "Types.h"

    using namespace Solomon::Types;
	//
	//
    // request to be sent whenever a connection will be closed by server
    class DLL_ACTION BodyMessage_80_8 : public AbstractBodyMessage {
        private:
            SmallString                 trustedPassword;

		public:
            BodyMessage_80_8();
            BodyMessage_80_8(DataContainerReader *buffer);
            virtual ~BodyMessage_80_8();

            void						SetTrustedPassword(string value);
            const u_buffer_pointer      GetTrustedPassword();
            //
            // virtual functions to provide:
			AbstractResponseMessage *	CreateResponseObject(DataContainerReader *binary_response);
            DataContainerWriter *		GetBodyMessage(void);
            byte						IDService(void);
            byte						IDMessage(void);
	};

#endif // _BodyMessage_80_8_H
