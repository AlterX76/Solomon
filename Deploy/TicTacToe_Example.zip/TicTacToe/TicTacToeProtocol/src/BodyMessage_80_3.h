


#ifndef _BODYMESSAGE_80_3_H

    #define _BODYMESSAGE_80_3_H

	#include "Solomon.h"
	#include "MemorySupport.h"
	#include "DataContainerReader.h"
	#include "DataContainerWriter.h"
    #include "AbstractBodyMessage.h"
    #include "ResponseMessage_80_3.h"
    #include "TicTacToeHeader.h"
	//
	//
    // request is used to send information over internet about action taken by a player
    class DLL_ACTION BodyMessage_80_3 : public AbstractBodyMessage {
		private:            
            Short                       actionIndex;

		public:
            BodyMessage_80_3();
            BodyMessage_80_3(DataContainerReader *buffer);
            virtual ~BodyMessage_80_3();

            void                        SetActionIndex(u_short);
            u_short                     GetActionIndex();
            //
            // virtual functions to provide:
			AbstractResponseMessage *	CreateResponseObject(DataContainerReader *binary_response);
            DataContainerWriter *		GetBodyMessage(void);
            byte						IDService(void);
            byte						IDMessage(void);
	};

#endif // _BodyMessage_80_3_H
