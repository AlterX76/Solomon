


#include "ResponseMessage_80_1.h"
#include "MemorySupport.h"


ResponseMessage_80_1::ResponseMessage_80_1(byte idService, byte idMessage) : idService(idService), idMessage(idMessage)
{
}


ResponseMessage_80_1::~ResponseMessage_80_1()
{
}


void ResponseMessage_80_1::SetNickname(string value)
{
    this->nickname.set(value);
}

const u_buffer_pointer ResponseMessage_80_1::GetNickname()
{
    return (this->nickname.get());
}


void ResponseMessage_80_1::SetSessionToken(string value)
{
    this->sessionToken.set(value);
}

const u_buffer_pointer ResponseMessage_80_1::GetSessionToken()
{
    return (this->sessionToken.get());
}

void ResponseMessage_80_1::SetFirstActionInGame(byte value)
{
    this->firstActionInGame.set(value);
}

byte ResponseMessage_80_1::GetFirstActionInGame()
{
    return (this->firstActionInGame.get());
}

byte ResponseMessage_80_1::IDService()
{
    return this->idService;
}

byte ResponseMessage_80_1::IDMessage()
{
    return this->idMessage;
}

// based on protocol specifications:
void ResponseMessage_80_1::ParseBinary(DataContainerReader *reader)
{    
    if (reader != NULL) {
        reader->Extract(&this->m_result);
        this->sessionToken.readFrom(reader);
        this->nickname.readFrom(reader);
        this->firstActionInGame.readFrom(reader);
    }
}


// based on protocol specifications:
DataContainerWriter * ResponseMessage_80_1::GetBodyMessage(void)
{
    DataContainerWriter *bodyStream = this->initBodyStream(this->nickname.size() + sizeof(this->m_result) + this->sessionToken.size() + this->firstActionInGame.size());

    bodyStream->Put(this->m_result);
    this->sessionToken.writeIn(bodyStream);
    this->nickname.writeIn(bodyStream);
    this->firstActionInGame.writeIn(bodyStream);
    return (bodyStream);
}
//
// due to it represents itself a response, we return NULL
AbstractResponseMessage *ResponseMessage_80_1::CreateResponseObject(DataContainerReader *)
{
    return (NULL);
}
