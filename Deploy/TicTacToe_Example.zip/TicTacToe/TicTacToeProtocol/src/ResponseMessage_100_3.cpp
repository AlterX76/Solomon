


#include "ResponseMessage_100_3.h"
#include "MemorySupport.h"


ResponseMessage_100_3::ResponseMessage_100_3(byte idService, byte idMessage) : idService(idService), idMessage(idMessage)
{
}


ResponseMessage_100_3::~ResponseMessage_100_3()
{
}

void ResponseMessage_100_3::SetActionIndex(u_short value)
{
    this->actionIndex.set(value);
}

u_short ResponseMessage_100_3::GetActionIndex()
{
    return (this->actionIndex.get());
}


byte ResponseMessage_100_3::IDService()
{
    return (SERVICE_NOTIFICATION);
}

byte ResponseMessage_100_3::IDMessage()
{
    return (3);
}


void ResponseMessage_100_3::ParseBinary(DataContainerReader *reader)
{
    if (reader != NULL) {
        reader->Extract(&this->m_result);
        this->actionIndex.readFrom(reader);
    }
}
//
//
// create a new body object, fill it with object's members and return it:
DataContainerWriter * ResponseMessage_100_3::GetBodyMessage(void)
{
    DataContainerWriter *bodyStream = this->initBodyStream(sizeof(this->m_result) + this->actionIndex.size());

    bodyStream->Put(this->m_result);
    this->actionIndex.writeIn(bodyStream);
    return (bodyStream);
}
//
// due to it represents itself a response, we return NULL
AbstractResponseMessage *ResponseMessage_100_3::CreateResponseObject(DataContainerReader *)
{
    return (NULL);
}
