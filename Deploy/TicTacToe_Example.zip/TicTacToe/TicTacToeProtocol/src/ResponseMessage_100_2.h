

#ifndef _RESPONSE_MESSAGE_100_2_H

    #define _RESPONSE_MESSAGE_100_2_H

	#include "Solomon.h"
    #include "SolomSmallString.h"
    #include "ResponseMessage_80_2.h"
	//
	//
    class DLL_ACTION ResponseMessage_100_2 : public ResponseMessage_80_2 {
		private:
            ResponseMessage_100_2& operator=(const ResponseMessage_100_2&);
            ResponseMessage_100_2(const ResponseMessage_100_2&);

		public:
            ResponseMessage_100_2(byte idService, byte idMessage);
            ~ResponseMessage_100_2();
	};

#endif // _RESPONSE_MESSAGE_80_1_H
