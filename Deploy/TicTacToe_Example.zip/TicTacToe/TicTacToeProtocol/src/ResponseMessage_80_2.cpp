


#include "ResponseMessage_80_2.h"
#include "MemorySupport.h"
#include "DataContainerReader.h"
#include "DataContainerWriter.h"


ResponseMessage_80_2::ResponseMessage_80_2(byte idService, byte idMessage) : idService(idService), idMessage(idMessage)
{
}


ResponseMessage_80_2::~ResponseMessage_80_2()
{
}


void ResponseMessage_80_2::ParseBinary(DataContainerReader *reader)
{    
    if (reader != NULL) {
        reader->Extract(&this->m_result);
    }
}
//
//
// create a new body object, fill it with object's members and return it:
DataContainerWriter * ResponseMessage_80_2::GetBodyMessage(void)
{
    DataContainerWriter *bodyStream = this->initBodyStream(sizeof(this->m_result));

    bodyStream->Put(this->m_result);
    return (bodyStream);
}
//
// due to it represents itself a response, we return NULL
AbstractResponseMessage *ResponseMessage_80_2::CreateResponseObject(DataContainerReader *)
{
    return (NULL);
}

byte ResponseMessage_80_2::IDService()
{
    return (this->idService);
}

byte ResponseMessage_80_2::IDMessage()
{
    return (this->idMessage);
}
