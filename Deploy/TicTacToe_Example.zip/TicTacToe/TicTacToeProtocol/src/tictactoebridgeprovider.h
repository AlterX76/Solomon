#ifndef _TicTacToeBridgeProvider_H
#define _TicTacToeBridgeProvider_H

#ifndef MOBILE_BUILD

#include "IServerBridgeProvider.h"
#include "TicTacToeHeader.h"
#include "Types.h"
//
//
// extend BaseInfoClient if you need to have custom data per connection
class TicTacToeData : public BaseInfoClient {
public:
    string  SessionTokenID; // unique session ID used during game
    sock    networkUserSocket; // socket reppresents the other peer
    Byte    performFirstAction; // who will start first in the game

    TicTacToeData();
};
//
// this object goes thru the pipeline of server to address ad-hoc protocol specifications:
class TicTacToeBridgeProvider : public IServerBridgeProvider
{
public:
    TicTacToeBridgeProvider();
    ~TicTacToeBridgeProvider();

public:
    AbstractHeaderMessage * createHeaderMessage();
    BaseInfoClient *        createMemorySlot();
    TPairMessage *          serverWillCloseConnection(const BaseInfoClient *info);
};

#endif
#endif // _TicTacToeBridgeProvider_H
