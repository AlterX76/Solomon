


#ifndef _RESPONSE_MESSAGE_80_3_H

    #define _RESPONSE_MESSAGE_80_3_H

	#include "Solomon.h"
    #include "AbstractResponseMessage.h"
	//
	//
    // response from request 80.3:
    class DLL_ACTION ResponseMessage_80_3 : public AbstractResponseMessage {
		private:
            byte                        idService;
            byte                        idMessage;

            ResponseMessage_80_3& operator=(const ResponseMessage_80_3&);
            ResponseMessage_80_3(const ResponseMessage_80_3&);

		public:
            ResponseMessage_80_3(byte idService, byte idMessage);
            ~ResponseMessage_80_3();
			//
			// virtual functions to provide:
			DataContainerWriter *		GetBodyMessage(void); 
			void						ParseBinary(DataContainerReader *reader);
            AbstractResponseMessage *   CreateResponseObject(DataContainerReader *binary_response);
            byte                        IDService();
            byte                        IDMessage();
	};

#endif // _RESPONSE_MESSAGE_80_1_H
