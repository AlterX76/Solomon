


#ifndef _RETURNSTATUS_H

	#define _RETURNSTATUS_H
	//
    //
    // what server can respond to clients:
	enum ReturnStatus {
        retNetworkError = 0, // if network issue
        retUnknown = 1,
        retMalformedPacket = 2, // if format of request is not valid
        retDatabaseCommunicationError = 3, // if database issue
        retErrorDuplicateEntry = 4, // if an entry can have same unique key (couldn't happen in this case)
        retErrorRetryLater = 5, // if logout issue
        retErrorDelivery = 6, // if a delivery issue
        retActionDelivered = 7, // action delivered to other peer successfully
        retTooShortNickname = 8, // nickname too short
        retTooLongNickname = 9, // nickname too long

        retGameClosed = 122, // if game is closed by one
        retLogoutExecuted = 126, // if logout has been performed
        retNoErrorWait = 127, // if player has joined network and is waiting for a peer
        retNoErrorGame = 128 // if player has joined network and game with peer has been started
	};

#endif // _RETURNSTATUS_H
