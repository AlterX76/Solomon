



#ifndef _RESPONSE_MESSAGE_100_3_H

    #define _RESPONSE_MESSAGE_100_3_H

    #include "Solomon.h"
    #include "SolomLargeString.h"
    #include "AbstractResponseMessage.h"
    #include "TicTacToeHeader.h"
    //
    //
    // notification of action taken by a player:
    class DLL_ACTION ResponseMessage_100_3 : public AbstractResponseMessage {
        private:
            byte                        idService;
            byte                        idMessage;
            Short                       actionIndex;

            ResponseMessage_100_3& operator=(const ResponseMessage_100_3&);
            ResponseMessage_100_3(const ResponseMessage_100_3&);

        public:
            ResponseMessage_100_3(byte idService, byte idMessage);
            ~ResponseMessage_100_3();

            void                        SetActionIndex(u_short);
            u_short                     GetActionIndex();
            //
            // virtual functions to provide:
            DataContainerWriter *		GetBodyMessage(void); 
            void						ParseBinary(DataContainerReader *reader);
            AbstractResponseMessage *   CreateResponseObject(DataContainerReader *binary_response);
            byte						IDService(void); 
            byte						IDMessage(void); 
    };

#endif
