


#ifndef _RESPONSE_MESSAGE_80_2_H

    #define _RESPONSE_MESSAGE_80_2_H

	#include "Solomon.h"
    #include "SolomSmallString.h"
    #include "AbstractResponseMessage.h"
	//
	//
    // disconnection response:
    class DLL_ACTION ResponseMessage_80_2 : public AbstractResponseMessage {
		private:
            byte                        idService;
            byte                        idMessage;

            ResponseMessage_80_2& operator=(const ResponseMessage_80_2&);
            ResponseMessage_80_2(const ResponseMessage_80_2&);

		public:
            ResponseMessage_80_2(byte idService, byte idMessage);
            ~ResponseMessage_80_2();
			//
			// virtual functions to provide:
			DataContainerWriter *		GetBodyMessage(void); 
			void						ParseBinary(DataContainerReader *reader);
            AbstractResponseMessage *   CreateResponseObject(DataContainerReader *binary_response);
            byte                        IDService();
            byte                        IDMessage();
	};

#endif // _RESPONSE_MESSAGE_80_1_H
