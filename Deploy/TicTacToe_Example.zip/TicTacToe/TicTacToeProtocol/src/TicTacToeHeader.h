


#ifndef _TICTACTOE_H

    #define _TICTACTOE_H

    #include "Solomon.h"
    #include "AbstractHeaderMessage.h"
    #include "DataContainerReader.h"
    #include "DataContainerWriter.h"
    #include "Types.h"
    //
    // PROTOCOL SERVICE NUMBERS:
    #define SERVICE_TICTACTOE_GAME  	80
    #define SERVICE_NOTIFICATION        100
    //
    // visibility for new types:
    using namespace Solomon::Types;
    //
    //
    // Header used by TicTacToe game example:
    class DLL_ACTION TicTacToeHeader : public AbstractHeaderMessage {
        private:
            SmallString             session_token;
            SolomStringBuffer       fixedSessionToken; // always same number of bytes: if less then, fill with space
            integer                 id_ticket; // socket id sent by server after successful connection

		public:
            TicTacToeHeader();
            ~TicTacToeHeader();
			//
            // public method to use:
            void                    SetClientTicket(integer value);
            integer                 GetClientTicket();
            void                    SetSessionToken(string value);
            buffer_pointer          GetSessionToken(); // the caller has responsibility to deallocate the returned buffer
            //
            // virtual function from AbstractHeaderMessage:
            byte                    SizeOfHeader(); // total dimension of header
            void                    ParseReader(DataContainerReader *reader); // used to parse a reader and extract info according to this object
            void                    WriteIn(DataContainerWriter *writer, size_t lenBody); // used to write in and put all information according to this object
	};
	
#endif // _TICTACTOE_H
