#ifndef ICHAIN_H
    #define ICHAIN_H

    #ifndef MOBILE_BUILD

    #include "Solomon.h"
    //
    // definizione della classe:
    class IChainCommand;
    class AbstractHeaderMessage;
    class ClientContainer;
    class SingleChainInfo;
    //
    // definizione di una lista di chain:
    typedef struct SingleChainInfo *    CommandsChainQueue;
    //
    //
    // Interfaccia da utilizzare per la creazione dei moduli della chain
    class IChainCommand {
        protected:
            IChainCommand               *next; // rappresenta l'elemento successivo della catena
            void                        *dynReference; // mantiene il riferimento al plugin caricato; usata per la chiusura del plugin

        public:
            IChainCommand();
            virtual ~IChainCommand();
            //
            // funzione per la discesa nella catena alla ricerca di command in grado di gestire la richiesta del client:
            static IChainCommand *      goThruChain(IChainCommand *starter, AbstractHeaderMessage *header, ClientContainer *clientRequest);
            static CommandsChainQueue   buildChain(buffer_pointer path, byte idService = 0, byte idMessage = 0, IChainCommand **shortcut = NULL); // nel percorso path si troveranno i commands divisi in directory col nome del servizio
            static void                 destroyChain(CommandsChainQueue *chains);
            //
            // funzioni virtuali da implementare:
            virtual boolean             canManage(byte service, byte message) = 0;
            virtual IChainCommand *     handler(AbstractHeaderMessage *header, ClientContainer *clientRequest) = 0;
    };

    #endif
#endif // ICHAIN_H
