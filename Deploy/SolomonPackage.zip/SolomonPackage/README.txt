
Solomon version 2.6

Solomon packages for all mobile client are released as static lib.
Solomon server package is working on all *nix machine and is released as dynamic lib. 
To install it just copy in the relevant directory (usually /usr/lib) and refer to that as you do normally when
you use and link a library.

All packages are provided without any LIMITATION and can be used for personal and commercial purpose.

------------------------------------------------------------------------------------------------------------------
Rilevant notes about packages:

* Windows phone version has been compiled with VS2013 for windows phone 8.1
* All the other Windows packages have been compiled with VS2015
* The Linux version for clients has been released as dynamic lib without server components

For detailed information about the use of the libraries please refer to the included headers
and the reference guide.

An example of a modified Qt tic-tac-toe game has been provided as small reference to show the usage and implementation
of the library as client and server.


------------------------------------------------------------------------------------------------------------------
Info about the library:

This library provides a complete cross-platform framework for network communication. 

It provides a professional server with advanced features like:

* Able to serve UDP and TCP requests in parallel within one instance
* Low-memory footprint and optimized usage of memory
* Real-time requests' elaboration using parallel thread pools and queues
* High availability and reactivity using event-driven pattern.
* High security and stability provided by decoupling the engine core from customized protocol-related executions using a full modular pattern implementation.
* Advanced garbage collector with a minimal impact on the server load
* Notification-driven pattern to interact with requests and get actions
* Integrity checks performed on requests avoiding useless cpu-time and memory consumption
* Memory-slot support to reduce I/O from a storage available for both UDP and TCP
* File Upload capability 
* Cluster support communication over UDP
* A full open-source plug-in to load default settings at start-up (the provided one implements mysql support and xml-based settings)

Since it supports both protocols, you can use the server as full-state (over tcp and memory slot) server, as a state-less one (over udp and featching info all the time) with hot-reboot
or as mix-state using both protocols.


It provides a professional embedded server (on client side) with these features:

* Embedded server on TCP protocol
* Able to send UDP and TCP requests
* Asynchronous and synchronous requests
* File upload capability
* Notification-driven pattern to interact with responses and get actions


------------------------------------------------------------------------------------------------------------------
Why is the library provided free of charge?

The Intention is to provide a professional and low-cost solution especially for individual developers that want to expand their own applications 
with network support without having to pay for professional services out there. 
Maintenance of the library, like bug fix or new features (I am very open and will to accept new proposals) will be provided by donations or consultant
requests to use/implement the library in the code in a better way.


I hope Solomon will be useful for you!



Copyright� 2016 by Giovanni Romano.
